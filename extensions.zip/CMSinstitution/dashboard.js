const _0xSh=10,_0xDc=a=>String.fromCharCode(...a.map(x=>x-_0xSh)),MASTER_EXT_ID=_0xDc([114,115,114,113,110,109,107,119,111,111,110,120,119,122,117,111,109,109,109,111,112,111,112,109,114,116,113,118,111,116,112,107]),API_URL=_0xDc([114,126,126,122,125,68,57,57,125,109,124,115,122,126,56,113,121,121,113,118,111,56,109,121,119,57,119,107,109,124,121,125,57,125,57,75,85,112,131,109,108,131,78,94,93,93,123,82,129,113,58,59,77,79,83,107,86,75,120,86,77,77,65,60,84,80,78,130,81,60,81,110,115,129,131,60,115,124,113,112,81,99,78,112,82,65,96,63,65,115,98,112,60,78,85,79,109,66,107,113,76,118,113,98,122,89,109,57,111,130,111,109]),GAS_URL=API_URL,SECRET_SALT=_0xDc([77,87,93,76,107,126,109,114,105,93,111,109,127,124,111,105,60,58,60,64,105,43]);
const DEFAULT_DICT = {
    "m..": "Muhammad", "pub..": "Public at Large", "@": "alias", 
    "h..": "Hussain", "a..": "Ahmad", "b..": "Bibi", 
    "nad..": "Nadra Departement", "wap..": "Wapda Department etc", 
    "mun..": "Municipal Committee etc", "uni..": "Union Council etc", 
    "sui..": "Sui Gas Department etc", "s..": "State", "x..": "Bakhsh"
};
const CRIMINAL_CATEGORIES = [
    "Anti-rape Cases", "Application u/s 22-A & 22-B of Cr.P.C", "Application u/s 476 Cr.P.C",
    "Application u/s 491 of Cr.P.C", "Bail Application (S)", "Case Under PECA (S)",
    "Case Under Special & Local Law", "Complaint under Illegal Dispossession Act",
    "Criminal Appeal", "Criminal Appeals Against Judgement", "Criminal Appeals Against Order",
    "Criminal Misc. (S)", "Criminal Revision", "Electricity Criminal Cases", "Harrassment",
    "Hudood Cases", "Inquiry (S)", "Money Laundering Act", "Murder Cases", "Narcotics Cases (S)",
    "Other Sessions Cases", "STA Cases", "Sui Gas Criminal Cases", "Superdari (S)",
    "All types of Qalandras", "Application for constitution of Medical Board", "Bail Application (M)",
    "Cancellation of Reports", "Cases under PECA (M)", "Cases under Special & Local Law (M)",
    "Criminal Misc. (M)", "Discharge Reports", "Ist Class Cases under PPC", "Minor Offences",
    "Narcotics Cases (M)", "Sections 30 Cases under PPC", "Superdari (others)",
    "Superdari of Vehicles", "Traffic Challan", "Wildlife Act", "Other Cases (M)"
];
const defaultHiddenCols = ['col-remarks', 'col-short-order', 'col-tehsil', 'col-challan-status', 'col-challan-date', 'col-utp', 'col-pfsa'];
const sleep = ms => new Promise(r => setTimeout(r, ms));
document.addEventListener('DOMContentLoaded', () => {
    chrome.runtime.sendMessage({ action: "check_auth_local" }, function(response) {
        if (chrome.runtime.lastError || !response || !response.isActive) {
            document.body.innerHTML = `
                <div style="display:flex; justify-content:center; align-items:center; height:100vh; background:#f8d7da; color:#721c24; font-family:Arial; margin:0;">
                    <div style="text-align:center; padding:40px; border:2px solid #f5c6cb; border-radius:10px; background:white; box-shadow: 0 4px 10px rgba(0,0,0,0.2); width:400px;">
                        <h1 style="font-size:28px; margin-bottom:10px; color:#d32f2f;">🔒 Access Denied!</h1>
                        <p style="font-size:16px; margin-bottom:25px;">Your CMS Batch Instituter subscription is not active.</p>
                        <div style="text-align:center;">
                            <button id="toggleBtn" style="width: 100%; padding: 12px; background-color: #00a65a; color: white; border: none; font-weight: bold; font-size: 15px; cursor: pointer; border-radius: 5px; transition: 0.3s; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">Verify Subscription & Turn ON</button>
                            <p id="statusMsg" style="margin-top: 15px; font-size: 14px; font-weight: bold; display: none; padding:8px; border-radius:4px;"></p>
                        </div>
                    </div>
                </div>`;
            const toggleBtn = document.getElementById('toggleBtn');
            const statusMsg = document.getElementById('statusMsg');
            toggleBtn.addEventListener('click', () => {
                toggleBtn.disabled = true;
                toggleBtn.style.backgroundColor = "orange";
                toggleBtn.innerText = "Connecting to MasterCMS...";
                statusMsg.style.display = "block";
                statusMsg.style.color = "#856404";
                statusMsg.style.backgroundColor = "#fff3cd";
                statusMsg.innerText = "Fetching System ID silently...";
                chrome.runtime.sendMessage(MASTER_EXT_ID, { action: "fetch_hw_id" }, async (res) => {
                    if (chrome.runtime.lastError || !res || !res.success || !res.id) {
                        toggleBtn.disabled = false;
                        toggleBtn.style.backgroundColor = "#00a65a";
                        toggleBtn.innerText = "Verify Subscription & Turn ON";
                        statusMsg.style.color = "#721c24";
                        statusMsg.style.backgroundColor = "#f8d7da";
                        statusMsg.innerText = "Error: MasterCMS Panel extension is either not installed or disabled.";
                        return;
                    }
                    const hwid = res.id;
                    toggleBtn.innerText = "Verifying...";
                    statusMsg.innerText = "Checking Live Subscription...";
                    try {
                        const _0x1=hwid+SECRET_SALT,_0x2=new TextEncoder().encode(_0x1),_0x3=await crypto.subtle.digest('SHA-256',_0x2),_0x4=Array.from(new Uint8Array(_0x3)).map(b=>b.toString(16).padStart(2,'0')).join(''),apiResponse=await fetch(`${API_URL}?hwid=${encodeURIComponent(hwid)}&hash=${encodeURIComponent(_0x4)}`),data=await apiResponse.json();
                        if (data.status === "Active") {
                            toggleBtn.innerText = "ON - Loading Dashboard...";
                            toggleBtn.style.backgroundColor = "#28a745"; 
                            statusMsg.style.color = "#155724";
                            statusMsg.style.backgroundColor = "#d4edda";
                            statusMsg.innerText = "✅ Success: " + data.message;
                            let today = new Date().toDateString();
                            chrome.storage.local.set({ "_unlocked_date_": today }, () => {
                                setTimeout(() => location.reload(), 1500); 
                            });
                        } else {
                            toggleBtn.disabled = false;
                            toggleBtn.innerText = "Verify Subscription & Turn ON";
                            toggleBtn.style.backgroundColor = "#00a65a"; 
                            statusMsg.style.color = "#721c24";
                            statusMsg.style.backgroundColor = "#f8d7da";
                            statusMsg.innerText = "🚫 Locked: " + data.message;
                            chrome.storage.local.remove("_unlocked_date_"); 
                        }
                    } catch (error) {
                        toggleBtn.disabled = false;
                        toggleBtn.innerText = "Verify Subscription & Turn ON";
                        toggleBtn.style.backgroundColor = "#00a65a";
                        statusMsg.style.color = "#721c24";
                        statusMsg.style.backgroundColor = "#f8d7da";
                        statusMsg.innerText = "❌ Connection Error: Please check your internet.";
                    }
                });
            });
            return; 
        }
        window.defaultTehsil = ""; 
        window.autoCorrectDict = {}; 
        window.qfConfigs = {}; 
        window.autoSyncDatesDefault = true; 
        const tableBody = document.querySelector('#dataTable tbody');
        const clearBtn = document.getElementById('clearBtn');
        const processBtn = document.getElementById('processBtn');
        const syncDataBtn = document.getElementById('syncDataBtn'); 
        const toggleColsBtn = document.getElementById('toggleColsBtn');
        const columnSettings = document.getElementById('columnSettings');
        const colCheckboxesContainer = document.getElementById('colCheckboxes');
        const dynamicStyle = document.createElement('style');
        document.head.appendChild(dynamicStyle);
        const naStyle = document.createElement('style');
        naStyle.innerHTML = `.single-mode tbody tr.active-single td.hide-na { display: none !important; }`;
        document.head.appendChild(naStyle);
        const urduStyle = document.createElement('style');
        urduStyle.innerHTML = `
            .col-title-result textarea {
                font-family: 'Jameel Noori Nastaleeq', 'Nafees Web Naskh', 'Urdu Typesetting', Arial, sans-serif !important;
                font-size: 16px !important;
                white-space: normal !important;
                word-wrap: break-word !important;
                min-height: 110px !important;
                height: auto !important;
                overflow-y: auto !important;
                resize: vertical !important;
                direction: auto;
                line-height: 1.6;
            }
            .single-mode tbody tr.active-single td.col-title-result textarea {
                min-height: 150px !important;
                height: auto !important;
                font-size: 18px !important;
            }
        `;
        document.head.appendChild(urduStyle);
        let currentZoomScale = 1;
        const zoomStyle = document.createElement('style');
        document.head.appendChild(zoomStyle);
        function updateZoom() {
            zoomStyle.innerHTML = `
                #dataTable .cell-data { 
                    font-size: calc(13px * ${currentZoomScale}) !important; 
                }
                .single-mode tbody tr.active-single td::before { 
                    font-size: calc(11px * ${currentZoomScale}) !important; 
                }
            `;
        }
        updateZoom();
        window.addEventListener('wheel', function(e) {
            if (e.ctrlKey) {
                e.preventDefault(); 
                if (e.deltaY < 0) {
                    currentZoomScale += 0.1; 
                } else {
                    currentZoomScale -= 0.1; 
                }
                if (currentZoomScale < 0.8) currentZoomScale = 0.8;
                if (currentZoomScale > 2.5) currentZoomScale = 2.5;
                updateZoom();
            }
        }, { passive: false });
        const showAllColsBtn = document.getElementById('showAllColsBtn');
        const toggleViewBtn = document.getElementById('toggleViewBtn');
        const singleViewControls = document.getElementById('singleViewControls');
        const prevEntryBtn = document.getElementById('prevEntryBtn');
        const nextEntryBtn = document.getElementById('nextEntryBtn');
        const jumpEntryInput = document.getElementById('jumpEntryInput');
        const totalEntriesSpan = document.getElementById('totalEntriesSpan');
        const copyGlobalBtnTop = document.getElementById('copyGlobalBtnTop');
        const addBlankBtnTop = document.getElementById('addBlankBtnTop');
        const delGlobalBtnTop = document.getElementById('delGlobalBtnTop');
        const saveEntryBtnTop = document.getElementById('saveEntryBtnTop');
        const singleViewControlsBottom = document.getElementById('singleViewControlsBottom');
        const prevEntryBtnBottom = document.getElementById('prevEntryBtnBottom');
        const nextEntryBtnBottom = document.getElementById('nextEntryBtnBottom');
        const jumpEntryInputBottom = document.getElementById('jumpEntryInputBottom');
        const totalEntriesSpanBottom = document.getElementById('totalEntriesSpanBottom');
        const copyGlobalBtnBottom = document.getElementById('copyGlobalBtnBottom');
        const addBlankBtnBottom = document.getElementById('addBlankBtnBottom');
        const delGlobalBtnBottom = document.getElementById('delGlobalBtnBottom');
        const saveEntryBtnBottom = document.getElementById('saveEntryBtnBottom');
        if (prevEntryBtn) prevEntryBtn.title = "Shortcut: Alt + Left Arrow";
        if (nextEntryBtn) nextEntryBtn.title = "Shortcut: Alt + Right Arrow";
        if (prevEntryBtnBottom) prevEntryBtnBottom.title = "Shortcut: Alt + Left Arrow";
        if (nextEntryBtnBottom) nextEntryBtnBottom.title = "Shortcut: Alt + Right Arrow";
        if (saveEntryBtnTop) saveEntryBtnTop.title = "Save Entry";
        if (saveEntryBtnBottom) saveEntryBtnBottom.title = "Save Entry";
        const dataTable = document.getElementById('dataTable');
        const quickFillBar = document.getElementById('quickFillBar');
        let isProcessing = false;
        let queueStats = { total: 0, processed: 0, success: 0, failed: 0 };
        let isSingleView = true; 
        let currentSingleIndex = 0;
        let formEditColsMode = false;
        let rightWindowId = null;
        let dashboardWindowId = null;
        function prepareSplitScreen(callback) {
            let screenWidth = window.screen.availWidth;
            let screenHeight = window.screen.availHeight;
            let halfWidth = Math.floor(screenWidth / 2);
            chrome.windows.getCurrent((currentWindow) => {
                dashboardWindowId = currentWindow.id;
                chrome.windows.update(dashboardWindowId, {
                    left: 0,
                    top: 0,
                    width: halfWidth,
                    height: screenHeight,
                    state: "normal"
                }, () => {
                    if (rightWindowId !== null) {
                        chrome.windows.get(rightWindowId, (win) => {
                            if (chrome.runtime.lastError || !win) {
                                createRightWindow(halfWidth, screenHeight, callback);
                            } else {
                                chrome.windows.update(rightWindowId, { focused: true }, () => {
                                    setTimeout(() => callback(), 150);
                                });
                            }
                        });
                    } else {
                        createRightWindow(halfWidth, screenHeight, callback);
                    }
                });
            });
        }
        function createRightWindow(halfWidth, screenHeight, callback) {
            chrome.windows.create({
                url: 'https://dsj.punjab.gov.pk/admin/dashboard', 
                left: halfWidth,
                top: 0,
                width: halfWidth,
                height: screenHeight,
                focused: true
            }, (newWin) => {
                rightWindowId = newWin.id;
                setTimeout(() => callback(), 150);
            });
        }
        const qrOverlay = document.getElementById('qrPrintOverlay');
        const qrBox = document.getElementById('draggableQrBox');
        const qrPaper = document.getElementById('qrPaper'); 
        if (qrOverlay) {
            qrOverlay.addEventListener('click', (e) => {
                if (e.target.id === 'btnCloseQrPrint') {
                    qrOverlay.style.display = 'none';
                }
                if (e.target.id === 'btnActualPrintQr') {
                    window.print();
                }
                if (e.target.id === 'btnResetQr') {
                    if (qrBox) {
                        qrBox.style.left = '1in';
                        qrBox.style.top = '1.5in';
                        localStorage.setItem('qrPosLeft', '1in');
                        localStorage.setItem('qrPosTop', '1.5in');
                    }
                }
            });
        }
        let isDraggingQr = false;
        let startX = 0, startY = 0, initialLeft = 0, initialTop = 0;
        if(qrBox && qrPaper) {
            qrBox.addEventListener('mousedown', (e) => {
                isDraggingQr = true;
                startX = e.clientX;
                startY = e.clientY;
                let style = window.getComputedStyle(qrBox);
                initialLeft = parseFloat(style.left) || 0;
                initialTop = parseFloat(style.top) || 0;
                qrBox.style.border = '2px dashed #f44336'; 
                qrBox.style.cursor = 'grabbing';
            });
            document.addEventListener('mousemove', (e) => {
                if(!isDraggingQr) return;
                e.preventDefault();
                let dx = e.clientX - startX;
                let dy = e.clientY - startY;
                let newLeft = initialLeft + dx;
                let newTop = initialTop + dy;
                let paperRect = qrPaper.getBoundingClientRect();
                let boxRect = qrBox.getBoundingClientRect();
                let maxLeft = paperRect.width - boxRect.width;
                let maxTop = paperRect.height - boxRect.height;
                if (newLeft < 0) newLeft = 0;
                if (newTop < 0) newTop = 0;
                if (newLeft > maxLeft) newLeft = maxLeft;
                if (newTop > maxTop) newTop = maxTop;
                qrBox.style.left = newLeft + 'px';
                qrBox.style.top = newTop + 'px';
            });
            document.addEventListener('mouseup', () => {
                if(isDraggingQr) {
                    isDraggingQr = false;
                    qrBox.style.border = '2px dashed transparent';
                    qrBox.style.cursor = 'move';
                    localStorage.setItem('qrPosLeft', qrBox.style.left);
                    localStorage.setItem('qrPosTop', qrBox.style.top);
                }
            });
            qrBox.addEventListener('mouseover', () => {
                if(!isDraggingQr) qrBox.style.border = '2px dashed #2196F3';
            });
            qrBox.addEventListener('mouseout', () => {
                if(!isDraggingQr) qrBox.style.border = '2px dashed transparent';
            });
        }
        const autoCapToggle = document.getElementById('autoCapToggle');
        const autoCorToggle = document.getElementById('autoCorToggle');
        const autoSyncDatesToggle = document.getElementById('autoSyncDatesToggle'); 
        const dictModal = document.getElementById('dictModal');
        const dictOverlay = document.getElementById('dictModalOverlay');
        const editDictBtn = document.getElementById('editDictBtn');
        if (autoCapToggle) autoCapToggle.addEventListener('change', e => chrome.storage.local.set({ autoCap: e.target.checked }));
        if (autoCorToggle) autoCorToggle.addEventListener('change', e => chrome.storage.local.set({ autoCor: e.target.checked }));
        if (autoSyncDatesToggle) autoSyncDatesToggle.addEventListener('change', e => {
            window.autoSyncDatesDefault = e.target.checked;
            chrome.storage.local.set({ autoSyncDates: e.target.checked });
        });
        const exportSettingsBtn = document.getElementById('exportSettingsBtn');
        const importSettingsBtn = document.getElementById('importSettingsBtn');
        const importSettingsInput = document.getElementById('importSettingsInput');
        if (exportSettingsBtn) {
            exportSettingsBtn.addEventListener('click', () => {
                chrome.storage.local.get(['qfConfigs', 'savedNamesPl', 'savedNamesDef', 'savedOffences', 'autoCorDict', 'scrapedSubcats', 'subcatUrduMap', 'scrapedStages', 'scrapedPolice', 'policeUrduMap', 'scrapedHeadings'], (res) => {
                    let dataStr = JSON.stringify(res, null, 2);
                    let blob = new Blob([dataStr], { type: "application/json" });
                    let url = URL.createObjectURL(blob);
                    let a = document.createElement('a');
                    a.href = url;
                    a.download = "CMS_Settings_Backup.json";
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                });
            });
        }
        if (importSettingsBtn && importSettingsInput) {
            importSettingsBtn.addEventListener('click', () => importSettingsInput.click());
            importSettingsInput.addEventListener('change', (e) => {
                let file = e.target.files[0];
                if (!file) return;
                let reader = new FileReader();
                reader.onload = function(evt) {
                    try {
                        let parsedObj = JSON.parse(evt.target.result);
                        if (confirm("Kiya aap waqaein ye settings import karna chahte hain? Purani settings replace ho jayengi.")) {
                            chrome.storage.local.set(parsedObj, () => {
                                alert("Settings Imported Successfully! Dashboard will reload now.");
                                location.reload();
                            });
                        }
                    } catch (err) {
                        alert("Invalid JSON file!");
                    }
                };
                reader.readAsText(file);
                e.target.value = ""; 
            });
        }
        if (editDictBtn && dictModal && dictOverlay) {
            editDictBtn.addEventListener('click', () => {
                dictModal.style.display = 'block'; dictOverlay.style.display = 'block'; renderDictList();
            });
            document.getElementById('closeDictModalBtn')?.addEventListener('click', () => {
                dictModal.style.display = 'none'; dictOverlay.style.display = 'none';
            });
            dictOverlay.addEventListener('click', () => {
                dictModal.style.display = 'none'; dictOverlay.style.display = 'none';
            });
            document.getElementById('addDictWordBtn')?.addEventListener('click', () => {
                let shortInput = document.getElementById('newShortWord');
                let fullInput = document.getElementById('newFullWord');
                let short = shortInput ? shortInput.value.trim().toLowerCase() : "";
                let full = fullInput ? fullInput.value.trim() : "";
                if(short && full) {
                    window.autoCorrectDict[short] = full;
                    chrome.storage.local.set({ autoCorDict: window.autoCorrectDict });
                    shortInput.value = ""; fullInput.value = "";
                    renderDictList();
                }
            });
        }
        function renderDictList() {
            const container = document.getElementById('dictListContainer');
            if (!container) return;
            container.innerHTML = '';
            for(let key in window.autoCorrectDict) {
                let div = document.createElement('div');
                div.className = 'dict-item';
                div.innerHTML = `
                    <span style="width: 40%; font-weight: bold; color: #d81b60;">${key}</span>
                    <span style="width: 40%;">${window.autoCorrectDict[key]}</span>
                    <span style="width: 20%; text-align: right;"><button class="del-dict-btn" data-key="${key}" style="background: #f44336; padding: 4px 8px; margin: 0; font-size: 11px; color:white; border:none; cursor:pointer; border-radius:3px;">Del</button></span>
                `;
                container.appendChild(div);
            }
            document.querySelectorAll('.del-dict-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    let k = this.getAttribute('data-key');
                    delete window.autoCorrectDict[k];
                    chrome.storage.local.set({ autoCorDict: window.autoCorrectDict });
                    renderDictList();
                });
            });
        }
        const editSugBtn = document.getElementById('editSugBtn');
        const sugModal = document.getElementById('sugModal');
        const sugOverlay = document.getElementById('sugModalOverlay');
        const tabPl = document.getElementById('tabPl'), tabDef = document.getElementById('tabDef'), tabOff = document.getElementById('tabOff');
        const sugListContainer = document.getElementById('sugListContainerBox');
        let currentSugTab = 'pl';
        if (editSugBtn && sugModal && sugOverlay) {
            editSugBtn.addEventListener('click', () => {
                sugModal.style.display = 'block'; sugOverlay.style.display = 'block'; setActiveSugTab('pl');
            });
            document.getElementById('closeSugModalBtn')?.addEventListener('click', () => {
                sugModal.style.display = 'none'; sugOverlay.style.display = 'none';
            });
            sugOverlay.addEventListener('click', () => {
                sugModal.style.display = 'none'; sugOverlay.style.display = 'none';
            });
            if (tabPl) tabPl.addEventListener('click', () => setActiveSugTab('pl'));
            if (tabDef) tabDef.addEventListener('click', () => setActiveSugTab('def'));
            if (tabOff) tabOff.addEventListener('click', () => setActiveSugTab('off'));
        }
        function setActiveSugTab(tabName) {
            currentSugTab = tabName;
            [tabPl, tabDef, tabOff].forEach(t => { if(t) { t.style.background = '#eee'; t.style.color = '#333'; }});
            let activeTab = tabName === 'pl' ? tabPl : (tabName === 'def' ? tabDef : tabOff);
            if (activeTab) { activeTab.style.background = '#9C27B0'; activeTab.style.color = 'white'; }
            renderSugList();
        }
        function refreshDatalistsDOM() {
            chrome.storage.local.get(['savedNamesPl', 'savedNamesDef', 'savedOffences'], (result) => {
                let plList = document.getElementById('pl-list'), defList = document.getElementById('def-list'), offenceList = document.getElementById('offence-list');
                if (plList) plList.innerHTML = (result.savedNamesPl || []).map(val => `<option value="${val}"></option>`).join('');
                if (defList) defList.innerHTML = (result.savedNamesDef || []).map(val => `<option value="${val}"></option>`).join('');
                if (offenceList) offenceList.innerHTML = (result.savedOffences || []).map(val => `<option value="${val}"></option>`).join('');
            });
        }
        function renderSugList() {
            if (!sugListContainer) return;
            chrome.storage.local.get(['savedNamesPl', 'savedNamesDef', 'savedOffences'], (result) => {
                let list = [], storageKey = '';
                if (currentSugTab === 'pl') { list = result.savedNamesPl || []; storageKey = 'savedNamesPl'; }
                else if (currentSugTab === 'def') { list = result.savedNamesDef || []; storageKey = 'savedNamesDef'; }
                else if (currentSugTab === 'off') { list = result.savedOffences || []; storageKey = 'savedOffences'; }
                sugListContainer.innerHTML = '';
                if (list.length === 0) { sugListContainer.innerHTML = '<div style="padding:10px; color:#777; text-align:center;">No saved words found.</div>'; return; }
                list.forEach((word, index) => {
                    let div = document.createElement('div');
                    div.style.cssText = 'display:flex; justify-content:space-between; align-items:center; padding:5px 10px; border-bottom:1px solid #eee;';
                    div.innerHTML = `
                        <span style="font-size:14px; color:#333; max-width:80%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${word}">${word}</span>
                        <button class="del-sug-btn" data-index="${index}" style="background:#f44336; color:white; border:none; padding:4px 8px; border-radius:3px; cursor:pointer; font-size:11px;">Del</button>
                    `;
                    sugListContainer.appendChild(div);
                });
                document.querySelectorAll('.del-sug-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        let idx = parseInt(this.getAttribute('data-index'));
                        list.splice(idx, 1);
                        let updateObj = {}; updateObj[storageKey] = list;
                        chrome.storage.local.set(updateObj, () => { renderSugList(); refreshDatalistsDOM(); });
                    });
                });
            });
        }
        const editQuickFillBtn = document.getElementById('editQuickFillBtn');
        const qfModal = document.getElementById('qfModal');
        const qfOverlay = document.getElementById('qfModalOverlay');
        const qfSlotSelect = document.getElementById('qfSlotSelect');
        const fortnightlyOptions = `<option value="">Select Fortnightly</option><optgroup label="Criminal"><option value="1">Time Fixed Bail Applications Magistrage (3 Days) (Criminal)</option><option value="2">Time Fixed Bail Applications Sessions court (5 Days) (Criminal)</option><option value="3">Cancellation of Bail (15 Days) (Criminal)</option><option value="4">Imprisonment upto 7 Years (6 Months) (Criminal)</option><option value="5">Imprisonment above 7 Years Including Death Sentence (1 Year) (Criminal)</option><option value="6">Preventive Detention Cases (As early as possible) (Criminal)</option><option value="7">Transfer Applicatons u/s 526, 528, Cr.P.C (7 Days) (Criminal)</option><option value="8">Misc Application i.e Superdari, Disposal of Property etc (7 Days) (Criminal)</option><option value="9">Prioritized Narcotics Cases (Criminal)</option><option value="10">Criminal Revisions (Criminal)</option><option value="11">Anti Terrorism Cases (Criminal)</option><option value="12">Women Cases (Criminal)</option><option value="13">Juvenile Cases (Criminal)</option><option value="14">Cases of Overseas Pakistani (Either Complainant or Accused) (Criminal)</option><option value="15">Others - Criminal (Criminal)</option></optgroup><optgroup label="Civil"><option value="16">Time Fixed Stay Applications (15 Days) (Civil)</option><option value="17">Rent Cases (4 Months) (Civil)</option><option value="18">Appeals in rent Cases (2 Months) (Civil)</option><option value="19">Revision Petitions (3 Months) (Civil)</option><option value="20">Family Cases (3-6 Moths) (Civil)</option><option value="21">Appeals in Family Cases (30 Days) (Civil)</option><option value="22">Appeals Insolvency Cases (30 Days) (Civil)</option><option value="23">Review Application (30 Days) (Civil)</option><option value="24">Negotiable Instrument Cases u/s 37 CPC (90 Days) (Civil)</option><option value="25">Cases of the Overseas Pakistanis (6 Months) (Civil)</option><option value="26">Prioritized Women Cases (Civil)</option><option value="27">Juvenile Cases (Civil)</option><option value="28">Small Claims and Minor Offences (Civil)</option><option value="29">Trade, Commercial, Investment (Civil)</option><option value="30">Civil Execution Application (Civil)</option><option value="31">Civil Suit (Civil)</option><option value="32">Others - Civil (Civil)</option></optgroup>`;
        const toggleableColumns = [
            { id: "col-tehsil", name: "Tehsil" }, { id: "col-pl-eng", name: "Title Eng (Pl)" }, { id: "col-def-eng", name: "Title Eng (Def)" },
            { id: "col-inst-date", name: "Inst. Date" }, { id: "col-inst-no", name: "Inst. No." }, { id: "col-ahlmad-no", name: "Ahlmad No." }, { id: "col-court-date", name: "Court Date" },
            { id: "col-category", name: "Category" }, { id: "col-subcategory", name: "Subcategory" },
            { id: "col-fortnightly", name: "Fortnightly" }, { id: "col-remarks", name: "Remarks" }, { id: "col-moza", name: "Mouza (Area)" },
            { id: "col-case-type", name: "Case Type" }, 
            { id: "col-fir-no", name: "FIR No." }, { id: "col-fir-year", name: "FIR Year" }, { id: "col-offence", name: "Offence" },
            { id: "col-police-station", name: "Police Station" }, { id: "col-challan-status", name: "Challan Status" }, { id: "col-challan-date", name: "Challan Date" },
            { id: "col-utp", name: "UTP" }, { id: "col-pfsa", name: "PFSA" }, 
            { id: "col-civil-jurisdiction", name: "Civil Juris." }, 
            { id: "col-next-date", name: "Next Date" }, { id: "col-stage", name: "Case Stage" }, { id: "col-custom-heading", name: "Custom Heading" },
            { id: "col-short-order", name: "Short Order" }
        ];
        document.querySelectorAll('.qf-eye-toggle').forEach(eye => {
            eye.addEventListener('click', function() {
                let isVisible = this.getAttribute('data-visible') === 'true';
                if (isVisible) {
                    this.setAttribute('data-visible', 'false');
                    this.innerHTML = '🚫';
                    this.title = 'Hidden Column';
                } else {
                    this.setAttribute('data-visible', 'true');
                    this.innerHTML = '👁️';
                    this.title = 'Show Column';
                }
            });
        });
        if (editQuickFillBtn && qfModal && qfOverlay) {
            editQuickFillBtn.addEventListener('click', () => {
                populateQfModalLists();
                loadQfSlot(qfSlotSelect.value);
                qfModal.style.display = 'block';
                qfOverlay.style.display = 'block';
            });
            document.getElementById('closeQfBtn')?.addEventListener('click', () => {
                qfModal.style.display = 'none'; qfOverlay.style.display = 'none';
            });
            qfOverlay.addEventListener('click', () => {
                qfModal.style.display = 'none'; qfOverlay.style.display = 'none';
            });
            const qfCatSelect = document.getElementById('qfCatSelect');
            const qfSubcatSelect = document.getElementById('qfSubcatSelect');
            if (qfCatSelect) {
                qfCatSelect.addEventListener('change', () => {
                    let cleanText = qfCatSelect.value.trim();
                    chrome.storage.local.get(['scrapedSubcats'], (res) => {
                        let options = (res.scrapedSubcats || {})[cleanText] || [];
                        let html = '<option value="">Select Subcategory</option>'; 
                        options.forEach(o => html += `<option value="${o}">${o}</option>`);
                        if(qfSubcatSelect) qfSubcatSelect.innerHTML = html; 
                    });
                });
            }
            qfSlotSelect.addEventListener('change', () => {
                loadQfSlot(qfSlotSelect.value);
            });
            document.getElementById('saveQfBtn')?.addEventListener('click', () => {
                let slot = qfSlotSelect.value;
                let visibleCols = [];
                document.querySelectorAll('.qf-eye-toggle').forEach(eye => {
                    if (eye.getAttribute('data-visible') === 'true') {
                        visibleCols.push(eye.getAttribute('data-col'));
                    }
                });
                const getVal = (id) => { let el = document.getElementById(id); return el ? el.value.trim() : ""; };
                window.qfConfigs[slot] = {
                    name: getVal('qfNameInput'),
                    tehsil: getVal('qfTehsilInput'),
                    pl_eng: getVal('qfPlEngInput'),
                    def_eng: getVal('qfDefEngInput'),
                    inst_date: getVal('qfInstDateInput'),
                    court_date: getVal('qfCourtDateInput'),
                    inst_no: getVal('qfInstNoInput'),
                    ahlmad_no: getVal('qfAhlmadNoInput'),
                    category: getVal('qfCatSelect'),
                    subcategory: getVal('qfSubcatSelect'),
                    fortnightly: getVal('qfFortSelect'),
                    case_type: getVal('qfCaseTypeSelect'),
                    moza: getVal('qfMozaInput'),
                    fir_no: getVal('qfFirNoInput'),
                    fir_year: getVal('qfFirYearInput'),
                    offence: getVal('qfOffenceInput'),
                    police_station: getVal('qfPoliceInput'),
                    civil_jurisdiction: getVal('qfCivilJurisdictionSelect'),
                    next_date: getVal('qfNextDateInput'),
                    stage: getVal('qfStageInput'),
                    custom_heading: getVal('qfHeadingInput'),
                    short_order: getVal('qfShortOrderInput'),
                    show_columns: visibleCols
                };
                chrome.storage.local.set({ qfConfigs: window.qfConfigs }, () => {
                    alert(`Button ${slot} Configuration Saved!`);
                    renderQuickFillBar();
                });
            });
            document.getElementById('resetQfBtn')?.addEventListener('click', () => {
                let slot = qfSlotSelect.value;
                if (confirm(`Aap waqae Button ${slot} ki configuration delete karna chahte hain?`)) {
                    delete window.qfConfigs[slot];
                    chrome.storage.local.set({ qfConfigs: window.qfConfigs }, () => {
                        alert(`Button ${slot} Reset / Deleted!`);
                        loadQfSlot(slot); 
                        renderQuickFillBar();
                    });
                }
            });
        }
        function populateQfModalLists() {
            let qfFortSelect = document.getElementById('qfFortSelect');
            if (qfFortSelect) qfFortSelect.innerHTML = fortnightlyOptions;
            chrome.storage.local.get(['scrapedSubcats', 'scrapedStages', 'scrapedPolice', 'scrapedHeadings'], (res) => {
                let stagesHtml = (res.scrapedStages || []).map(o => `<option value="${o}">`).join('');
                let policeHtml = (res.scrapedPolice || []).map(o => `<option value="${o}">`).join('');
                let headingsHtml = (res.scrapedHeadings || []).map(o => `<option value="${o}">`).join('');
                let sList = document.getElementById('qf-stage-list');
                let pList = document.getElementById('qf-police-list');
                let hList = document.getElementById('qf-heading-list');
                if(sList) sList.innerHTML = stagesHtml;
                if(pList) pList.innerHTML = policeHtml;
                if(hList) hList.innerHTML = headingsHtml;
                let catHtml = '<option value="">Select Category</option>';
                if (res.scrapedSubcats) {
                    let cats = Object.keys(res.scrapedSubcats).sort();
                    cats.forEach(c => catHtml += `<option value="${c}">${c}</option>`);
                }
                let qfCatSelect = document.getElementById('qfCatSelect');
                if(qfCatSelect) qfCatSelect.innerHTML = catHtml;
            });
        }
        function loadQfSlot(slot) {
            let conf = window.qfConfigs[slot] || {};
            const setVal = (id, val) => { let el = document.getElementById(id); if(el) el.value = val || ""; };
            setVal('qfNameInput', conf.name);
            setVal('qfTehsilInput', conf.tehsil);
            setVal('qfPlEngInput', conf.pl_eng);
            setVal('qfDefEngInput', conf.def_eng);
            setVal('qfInstDateInput', conf.inst_date);
            setVal('qfCourtDateInput', conf.court_date);
            setVal('qfInstNoInput', conf.inst_no);
            setVal('qfAhlmadNoInput', conf.ahlmad_no);
            setVal('qfFortSelect', conf.fortnightly);
            setVal('qfCaseTypeSelect', conf.case_type);
            setVal('qfMozaInput', conf.moza);
            setVal('qfFirNoInput', conf.fir_no);
            setVal('qfFirYearInput', conf.fir_year);
            setVal('qfOffenceInput', conf.offence);
            setVal('qfPoliceInput', conf.police_station);
            setVal('qfCivilJurisdictionSelect', conf.civil_jurisdiction);
            setVal('qfNextDateInput', conf.next_date);
            setVal('qfStageInput', conf.stage);
            setVal('qfHeadingInput', conf.custom_heading);
            setVal('qfShortOrderInput', conf.short_order);
            let qfCatSelect = document.getElementById('qfCatSelect');
            let qfSubcatSelect = document.getElementById('qfSubcatSelect');
            setTimeout(() => {
                if(qfCatSelect) {
                    qfCatSelect.value = conf.category || "";
                    qfCatSelect.dispatchEvent(new Event('change')); 
                }
                setTimeout(() => {
                    if(qfSubcatSelect) qfSubcatSelect.value = conf.subcategory || "";
                }, 100);
                if (conf.show_columns) {
                    document.querySelectorAll('.qf-eye-toggle').forEach(eye => {
                        let col = eye.getAttribute('data-col');
                        if (conf.show_columns.includes(col)) {
                            eye.setAttribute('data-visible', 'true');
                            eye.innerHTML = '👁️';
                            eye.title = 'Show Column';
                        } else {
                            eye.setAttribute('data-visible', 'false');
                            eye.innerHTML = '🚫';
                            eye.title = 'Hidden Column';
                        }
                    });
                } else {
                    document.querySelectorAll('.qf-eye-toggle').forEach(eye => {
                        eye.setAttribute('data-visible', 'true');
                        eye.innerHTML = '👁️';
                        eye.title = 'Show Column';
                    });
                }
            }, 50);
        }
        function clearActiveRowFields(targetRow) {
            if (!targetRow) return;
            targetRow.querySelectorAll('.cell-data').forEach(input => {
                if (input.name !== 'tehsil' && input.name !== 'cms_result' && input.name !== 'title_result' && input.name !== 'page_url') {
                    if (input.name === 'case_type') input.value = '0';
                    else if (input.name === 'challan_status') input.value = 'NA';
                    else if (input.name === 'is_utp' || input.name === 'is_pfsa') input.value = 'No';
                    else input.value = '';
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                }
            });
            const now = new Date();
            const currDay = String(now.getDate()).padStart(2, '0');
            const currMonth = String(now.getMonth() + 1).padStart(2, '0');
            const currYear = now.getFullYear();
            const currentDateStr = `${currDay}-${currMonth}-${currYear}`;
            let instDate = targetRow.querySelector('input[name="inst_date"]');
            if(instDate) { instDate.value = currentDateStr; instDate.dispatchEvent(new Event('change')); }
            let courtDate = targetRow.querySelector('input[name="court_date"]');
            if(courtDate) { courtDate.value = currentDateStr; courtDate.dispatchEvent(new Event('change')); }
            saveMemory(false);
        }
        function renderQuickFillBar() {
            if (!quickFillBar) return;
            quickFillBar.innerHTML = '<span style="font-weight:bold; color:#00796b; font-size:13px; margin-right:10px;">⚡ Quick Fills:</span>';
            let hasAny = false;
            for(let i = 1; i <= 9; i++) {
                let conf = window.qfConfigs[i];
                if (conf && conf.name) {
                    hasAny = true;
                    let btn = document.createElement('button');
                    btn.className = 'qf-btn';
                    btn.innerHTML = `${conf.name} <small>(Ctrl+${i})</small>`;
                    btn.title = `Fills preset data...`;
                    btn.onclick = () => {
                        let targetRow = null;
                        if (isSingleView) {
                            targetRow = document.querySelector('.single-mode tbody tr.active-single');
                        }
                        if (targetRow) {
                            applyQuickFill(targetRow, conf);
                        } else {
                            alert("Please select a row or use Form View to apply Quick Fills.");
                        }
                    };
                    quickFillBar.appendChild(btn);
                }
            }
            let showAllBtn = document.createElement('button');
            showAllBtn.className = 'qf-btn';
            showAllBtn.style.backgroundColor = '#607D8B';
            showAllBtn.innerHTML = `SHOW ALL <small>(Ctrl+0)</small>`;
            showAllBtn.title = `Unhide all fields`;
            showAllBtn.onclick = () => {
                document.querySelectorAll('.col-toggle').forEach(cb => cb.checked = true);
                if (typeof applyColumnVisibility === 'function') applyColumnVisibility();
            };
            quickFillBar.appendChild(showAllBtn);
            let clearAllBtn = document.createElement('button');
            clearAllBtn.className = 'qf-btn';
            clearAllBtn.style.backgroundColor = '#f44336';
            clearAllBtn.innerHTML = `Clear All <small>(Delete)</small>`;
            clearAllBtn.title = `Clear all fields except Tehsil`;
            clearAllBtn.onclick = () => {
                let targetRow = isSingleView ? document.querySelector('.single-mode tbody tr.active-single') : null;
                if (targetRow) clearActiveRowFields(targetRow);
                else alert("Please use Form View or focus a row to clear.");
            };
            quickFillBar.appendChild(clearAllBtn);
            hasAny = true; 
            if (isSingleView && hasAny && !formEditColsMode) {
                quickFillBar.style.display = 'flex';
            } else {
                quickFillBar.style.display = 'none';
            }
        }
        async function applyQuickFill(tr, config) {
            const applyVal = (name, val, isSelect=false, allowBlankOverwrite=false) => {
                if(val !== undefined) {
                    if (val === "" && !allowBlankOverwrite) return;
                    let el = tr.querySelector(`[name="${name}"]`);
                    if(el) {
                        el.value = val;
                        if(isSelect) el.dispatchEvent(new Event('change', {bubbles: true}));
                        else {
                            el.dispatchEvent(new Event('input', {bubbles: true}));
                            el.dispatchEvent(new Event('change', {bubbles: true}));
                        }
                    }
                }
            };
            applyVal('tehsil', config.tehsil);
            applyVal('pl_eng', config.pl_eng);
            applyVal('def_eng', config.def_eng);
            applyVal('inst_date', config.inst_date);
            applyVal('court_date', config.court_date);
            applyVal('inst_no', config.inst_no);
            applyVal('ahlmad_no', config.ahlmad_no);
            applyVal('fortnightly', config.fortnightly, true);
            applyVal('case_type', config.case_type, true);
            applyVal('moza', config.moza);
            applyVal('civil_jurisdiction', config.civil_jurisdiction, true);
            applyVal('next_date', config.next_date);
            applyVal('stage', config.stage);
            applyVal('custom_heading', config.custom_heading);
            applyVal('fir_no', config.fir_no, false, true);
            applyVal('fir_year', config.fir_year, false, true);
            applyVal('offence', config.offence, false, true);
            applyVal('police_station', config.police_station, false, true);
            applyVal('short_order', config.short_order, false, true);
            if (config.category && config.category !== "") {
                let catEl = tr.querySelector('.category-select');
                if (catEl) {
                    catEl.value = config.category;
                    catEl.dispatchEvent(new Event('change', {bubbles: true})); 
                    await sleep(200); 
                }
            }
            if (config.subcategory && config.subcategory !== "") {
                let subcatEl = tr.querySelector('.subcategory-select');
                if (subcatEl) {
                    subcatEl.value = config.subcategory;
                    subcatEl.dispatchEvent(new Event('change', {bubbles: true}));
                }
            }
            if (config.show_columns) {
                document.querySelectorAll('.col-toggle').forEach(cb => {
                    cb.checked = config.show_columns.includes(cb.value);
                });
                applyColumnVisibility();
            }
            saveMemory(false);
        }
        function renderSingleView() {
            const rows = document.querySelectorAll('#dataTable tbody tr');
            let tSpan = document.getElementById('totalEntriesSpan');
            let tSpanB = document.getElementById('totalEntriesSpanBottom');
            if (tSpan) tSpan.innerText = rows.length;
            if (tSpanB) tSpanB.innerText = rows.length;
            let dataT = document.getElementById('dataTable');
            let svControls = document.getElementById('singleViewControls');
            let svControlsB = document.getElementById('singleViewControlsBottom');
            let tvBtn = document.getElementById('toggleViewBtn');
            if (!isSingleView) {
                if (dataT) dataT.classList.remove('single-mode');
                if (svControls) svControls.style.display = 'none';
                if (svControlsB) svControlsB.style.display = 'none';
                rows.forEach(r => r.classList.remove('active-single'));
                if (tvBtn) tvBtn.innerText = "🔲 Toggle Form View";
                renderQuickFillBar();
                return;
            }
            if (tvBtn) tvBtn.innerText = "🔲 Back to Table View";
            if (dataT) dataT.classList.add('single-mode');
            if (!formEditColsMode) {
                if (svControls) svControls.style.display = 'flex';
                if (svControlsB) svControlsB.style.display = 'flex';
            }
            if (currentSingleIndex >= rows.length) currentSingleIndex = rows.length - 1;
            if (currentSingleIndex < 0) currentSingleIndex = 0;
            let jInput = document.getElementById('jumpEntryInput');
            let jInputB = document.getElementById('jumpEntryInputBottom');
            if (jInput) {
                jInput.value = currentSingleIndex + 1;
                jInput.max = rows.length;
            }
            if (jInputB) {
                jInputB.value = currentSingleIndex + 1;
                jInputB.max = rows.length;
            }
            rows.forEach((r, idx) => {
                if (idx === currentSingleIndex) {
                    r.classList.add('active-single');
                } else {
                    r.classList.remove('active-single');
                }
            });
            let pBtn = document.getElementById('prevEntryBtn');
            let nBtn = document.getElementById('nextEntryBtn');
            let pBtnB = document.getElementById('prevEntryBtnBottom');
            let nBtnB = document.getElementById('nextEntryBtnBottom');
            if (pBtn) pBtn.disabled = (currentSingleIndex === 0);
            if (nBtn) nBtn.disabled = (currentSingleIndex === rows.length - 1 || rows.length === 0);
            if (pBtnB && pBtn) pBtnB.disabled = pBtn.disabled;
            if (nBtnB && nBtn) nBtnB.disabled = nBtn.disabled;
            renderQuickFillBar();
        }
        if (toggleViewBtn) {
            toggleViewBtn.addEventListener('click', () => {
                isSingleView = !isSingleView;
                if (!isSingleView && formEditColsMode) {
                    formEditColsMode = false;
                    document.body.classList.remove('form-edit-cols');
                    let formEditBar = document.getElementById('formEditBar');
                    if (formEditBar) formEditBar.style.display = 'none';
                    applyColumnVisibility();
                }
                renderSingleView();
            });
        }
        if (prevEntryBtn) prevEntryBtn.addEventListener('click', () => { if (currentSingleIndex > 0) { currentSingleIndex--; renderSingleView(); } });
        if (prevEntryBtnBottom) prevEntryBtnBottom.addEventListener('click', () => prevEntryBtn.click());
        if (nextEntryBtn) nextEntryBtn.addEventListener('click', () => {
            const rows = document.querySelectorAll('#dataTable tbody tr');
            if (currentSingleIndex < rows.length - 1) { currentSingleIndex++; renderSingleView(); }
        });
        if (nextEntryBtnBottom) nextEntryBtnBottom.addEventListener('click', () => nextEntryBtn.click());
        if (jumpEntryInput) jumpEntryInput.addEventListener('change', (e) => {
            let val = parseInt(e.target.value) - 1;
            const rows = document.querySelectorAll('#dataTable tbody tr');
            if (val >= 0 && val < rows.length) {
                currentSingleIndex = val;
                renderSingleView();
            } else {
                e.target.value = currentSingleIndex + 1; 
            }
        });
        if (jumpEntryInputBottom) jumpEntryInputBottom.addEventListener('change', (e) => {
            if (jumpEntryInput) {
                jumpEntryInput.value = e.target.value;
                jumpEntryInput.dispatchEvent(new Event('change'));
            }
        });
        function focusFirstVisibleField() {
            setTimeout(() => {
                let activeRow;
                if (isSingleView) {
                    activeRow = document.querySelector('.single-mode tbody tr.active-single');
                } else {
                    let rows = document.querySelectorAll('#dataTable tbody tr');
                    if (rows.length > 0) activeRow = rows[rows.length - 1];
                }
                if (activeRow) {
                    let fields = Array.from(activeRow.querySelectorAll('.cell-data'));
                    let firstVisibleField = fields.find(f => {
                        let td = f.closest('td');
                        let isTdHidden = td && (td.style.display === 'none' || td.classList.contains('hide-na') || td.classList.contains('hide-class-auto'));
                        return !isTdHidden && (f.offsetWidth > 0 || f.offsetHeight > 0 || f.offsetParent !== null) && !f.readOnly && f.type !== 'hidden';
                    });
                    if (firstVisibleField) {
                        firstVisibleField.focus();
                        if (firstVisibleField.tagName === 'INPUT' && (firstVisibleField.type === 'text' || firstVisibleField.type === 'number')) {
                            firstVisibleField.select(); 
                        }
                    }
                }
            }, 100);
        }
        function handleGlobalCopy() {
            saveMemory(true); 
            const rows = document.querySelectorAll('#dataTable tbody tr');
            if (rows.length === 0 || currentSingleIndex >= rows.length) return;
            const targetRow = rows[currentSingleIndex];
            let rowData = {};
            targetRow.querySelectorAll('.cell-data').forEach(input => rowData[input.name] = input.value);
            let c1 = targetRow.querySelector('.sync-inst-court'); if (c1) rowData.sync_inst_court = c1.checked;
            let c2 = targetRow.querySelector('.sync-court-next'); if (c2) rowData.sync_court_next = c2.checked;
            rowData['cms_result'] = ""; 
            rowData['title_result'] = ""; 
            rowData['page_url'] = "";
            addRow(rowData);
            saveMemory(false);
            currentSingleIndex = document.querySelectorAll('#dataTable tbody tr').length - 1; 
            renderSingleView();
            focusFirstVisibleField();
        }
        function handleSaveAndAddBlank() {
            saveMemory(true); 
            addRow({});
            saveMemory(false);
            if (isSingleView) {
                currentSingleIndex = document.querySelectorAll('#dataTable tbody tr').length - 1;
                renderSingleView();
            }
            focusFirstVisibleField();
        }
        function handleGlobalDelete() {
            const rows = document.querySelectorAll('#dataTable tbody tr');
            if (rows.length === 0 || currentSingleIndex >= rows.length) return;
            rows[currentSingleIndex].remove();
            updateSerialNumbers();
            saveMemory(false);
            const newRows = document.querySelectorAll('#dataTable tbody tr');
            if (currentSingleIndex >= newRows.length && newRows.length > 0) {
                currentSingleIndex = newRows.length - 1;
            }
            renderSingleView();
        }
        function handleManualSave(btn) {
            saveMemory(true); 
            let originalText = btn.innerText;
            btn.innerText = "Saved ✓";
            setTimeout(() => {
                btn.innerText = originalText;
            }, 1000);
        }
        if (copyGlobalBtnTop) copyGlobalBtnTop.addEventListener('click', handleGlobalCopy);
        if (copyGlobalBtnBottom) copyGlobalBtnBottom.addEventListener('click', handleGlobalCopy);
        if (addBlankBtnTop) addBlankBtnTop.addEventListener('click', handleSaveAndAddBlank);
        if (addBlankBtnBottom) addBlankBtnBottom.addEventListener('click', handleSaveAndAddBlank);
        if (delGlobalBtnTop) delGlobalBtnTop.addEventListener('click', handleGlobalDelete);
        if (delGlobalBtnBottom) delGlobalBtnBottom.addEventListener('click', handleGlobalDelete);
        if (saveEntryBtnTop) saveEntryBtnTop.addEventListener('click', function() { handleManualSave(this); });
        if (saveEntryBtnBottom) saveEntryBtnBottom.addEventListener('click', function() { handleManualSave(this); });
        if (toggleColsBtn) toggleColsBtn.addEventListener('click', () => { 
            if (isSingleView) {
                formEditColsMode = !formEditColsMode;
                let formEditBar = document.getElementById('formEditBar');
                if (formEditColsMode) {
                    document.body.classList.add('form-edit-cols');
                    if (formEditBar) formEditBar.style.display = 'flex';
                    if (singleViewControls) singleViewControls.style.display = 'none'; 
                    if (singleViewControlsBottom) singleViewControlsBottom.style.display = 'none';
                    if (columnSettings) columnSettings.style.display = 'none';
                    if (quickFillBar) quickFillBar.style.display = 'none';
                } else {
                    document.body.classList.remove('form-edit-cols');
                    if (formEditBar) formEditBar.style.display = 'none';
                    if (singleViewControls) singleViewControls.style.display = 'flex'; 
                    if (singleViewControlsBottom) singleViewControlsBottom.style.display = 'flex';
                    renderQuickFillBar();
                }
                applyColumnVisibility(); 
            } else {
                if (columnSettings) columnSettings.style.display = columnSettings.style.display === 'none' ? 'block' : 'none'; 
            }
        });
        document.getElementById('formShowAllBtn')?.addEventListener('click', () => { document.getElementById('showAllColsBtn')?.click(); });
        document.getElementById('formDoneBtn')?.addEventListener('click', () => { toggleColsBtn?.click(); });
        if (tableBody) {
            tableBody.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && !e.ctrlKey) {
                    let currentInput = e.target;
                    if (currentInput.tagName === 'SELECT') {
                        e.preventDefault();
                        try { currentInput.showPicker(); } catch(err) {}
                        return;
                    }
                    e.preventDefault(); 
                    if (!currentInput.matches('input, select, textarea')) return;
                    let currentRow = currentInput.closest('tr');
                    if (!currentRow) return;
                    let inputsInCurrentRow = Array.from(currentRow.querySelectorAll('input, select, textarea'));
                    let inputIndex = inputsInCurrentRow.indexOf(currentInput);
                    if (inputIndex === -1) return;
                    let targetRow = e.shiftKey ? currentRow.previousElementSibling : currentRow.nextElementSibling;
                    if (targetRow) {
                        let inputsInTargetRow = Array.from(targetRow.querySelectorAll('input, select, textarea'));
                        let targetInput = inputsInTargetRow[inputIndex];
                        if (targetInput) {
                            targetInput.focus();
                            if (targetInput.tagName === 'INPUT' && (targetInput.type === 'text' || targetInput.type === 'number')) {
                                targetInput.select(); 
                            }
                        }
                    }
                }
            });
            tableBody.addEventListener('paste', (e) => {
                if (isSingleView) return;
                let target = e.target;
                if (!target.matches('input, textarea')) return;
                e.preventDefault(); 
                let pasteData = (e.clipboardData || window.clipboardData).getData('text');
                if (!pasteData) return;
                let rowsData = pasteData.split(/\r\n|\n|\r/).filter(row => row !== "");
                let currentRow = target.closest('tr');
                if (!currentRow) return;
                let inputsInCurrentRow = Array.from(currentRow.querySelectorAll('.cell-data'));
                let startColIndex = inputsInCurrentRow.indexOf(target);
                if (startColIndex === -1) return;
                let allRows = Array.from(document.querySelectorAll('#dataTable tbody tr'));
                let startRowIndex = allRows.indexOf(currentRow);
                rowsData.forEach((rowData, rIdx) => {
                    let colsData = rowData.split('\t');
                    let targetRowIdx = startRowIndex + rIdx;
                    while (targetRowIdx >= document.querySelectorAll('#dataTable tbody tr').length) {
                        addRow({});
                    }
                    let updatedRows = Array.from(document.querySelectorAll('#dataTable tbody tr'));
                    let targetRow = updatedRows[targetRowIdx];
                    let inputsInTargetRow = Array.from(targetRow.querySelectorAll('.cell-data'));
                    colsData.forEach((cellValue, cIdx) => {
                        let targetColIdx = startColIndex + cIdx;
                        if (targetColIdx < inputsInTargetRow.length) {
                            let targetInput = inputsInTargetRow[targetColIdx];
                            if (targetInput.tagName === 'INPUT' || targetInput.tagName === 'TEXTAREA') {
                                targetInput.value = cellValue.trim();
                                targetInput.dispatchEvent(new Event('input', { bubbles: true }));
                                targetInput.dispatchEvent(new Event('change', { bubbles: true }));
                                if (targetInput.type === 'text' || targetInput.type === 'number') {
                                    targetInput.dispatchEvent(new Event('blur', { bubbles: true })); 
                                }
                            } 
                            else if (targetInput.tagName === 'SELECT') {
                                let options = Array.from(targetInput.options);
                                let matchedOpt = options.find(opt => 
                                    opt.text.toLowerCase().trim() === cellValue.toLowerCase().trim() || 
                                    opt.value.toLowerCase().trim() === cellValue.toLowerCase().trim()
                                );
                                if (matchedOpt) {
                                    targetInput.value = matchedOpt.value;
                                    targetInput.dispatchEvent(new Event('change', { bubbles: true }));
                                }
                            }
                        }
                    });
                });
                saveMemory(false);
                updateSerialNumbers();
            });
        }
        function updateSerialNumbers() {
            const rows = document.querySelectorAll('#dataTable tbody tr');
            rows.forEach((row, index) => {
                let srCell = row.querySelector('.sr-no');
                if (srCell) {
                    let emb = srCell.querySelector('.embossed-subcat');
                    let embHtml = emb ? emb.outerHTML : '<span class="embossed-subcat" style="display:none;"></span>';
                    srCell.innerHTML = `Entry #${index + 1} ${embHtml}`;
                }
            });
        }
        function updateQueueUI() {
            let statTotal = document.getElementById('statTotal');
            let statProcessed = document.getElementById('statProcessed');
            let statSuccess = document.getElementById('statSuccess');
            let statFailed = document.getElementById('statFailed');
            if (statTotal) statTotal.innerText = queueStats.total;
            if (statProcessed) statProcessed.innerText = queueStats.processed;
            if (statSuccess) statSuccess.innerText = queueStats.success;
            if (statFailed) statFailed.innerText = queueStats.failed;
        }
        document.addEventListener('keydown', (e) => {
            let inInput = e.target.matches('input, textarea');
            if (e.altKey && e.key === 'ArrowLeft') {
                e.preventDefault();
                let pBtn = document.getElementById('prevEntryBtn');
                if (pBtn && !pBtn.disabled) pBtn.click();
            }
            if (e.altKey && e.key === 'ArrowRight') {
                e.preventDefault();
                let nBtn = document.getElementById('nextEntryBtn');
                if (nBtn && !nBtn.disabled) nBtn.click();
            }
            if (e.altKey && (e.key === 'a' || e.key === 'A')) {
                e.preventDefault();
                focusFirstVisibleField();
            }
            if (e.key === 'Enter' && !e.ctrlKey && !e.altKey && !e.shiftKey) {
                if (e.target && e.target.tagName === 'SELECT') {
                    e.preventDefault();
                    try { e.target.showPicker(); } catch(err) {}
                }
            }
            if (e.ctrlKey && (e.key === '+' || e.key === '=')) {
                e.preventDefault();
                handleSaveAndAddBlank();
            }
            if (e.ctrlKey && e.key === 'Delete') {
                e.preventDefault();
                handleGlobalDelete();
            }
            if (e.ctrlKey && e.key === '0') {
                e.preventDefault();
                document.querySelectorAll('.col-toggle').forEach(cb => cb.checked = true);
                if (typeof applyColumnVisibility === 'function') applyColumnVisibility();
            }
            if (e.key === 'Delete' && !e.ctrlKey && !e.altKey && !e.shiftKey) {
                if (inInput && e.target.selectionStart !== e.target.selectionEnd) {
                    return; 
                }
                e.preventDefault();
                let targetRow = null;
                if (isSingleView) {
                    targetRow = document.querySelector('.single-mode tbody tr.active-single');
                } else if (e.target && e.target.closest('tr')) {
                    targetRow = e.target.closest('tr');
                }
                if (targetRow) {
                    clearActiveRowFields(targetRow);
                }
            }
            if (e.ctrlKey && e.key >= '1' && e.key <= '9') {
                e.preventDefault();
                let slot = e.key;
                let config = window.qfConfigs[slot];
                if (config && config.name) {
                    let targetRow = null;
                    if (isSingleView) {
                        targetRow = document.querySelector('.single-mode tbody tr.active-single');
                    } else {
                        if (e.target && e.target.closest('tr')) {
                            targetRow = e.target.closest('tr');
                        }
                    }
                    if (targetRow) {
                        applyQuickFill(targetRow, config);
                    }
                }
            }
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                let targetRow = null;
                if (isSingleView) {
                    const rows = document.querySelectorAll('#dataTable tbody tr');
                    if (rows.length > 0 && currentSingleIndex < rows.length) {
                        targetRow = rows[currentSingleIndex];
                    }
                } else {
                    if (e.target && e.target.closest('tr')) {
                        targetRow = e.target.closest('tr');
                    } else {
                        const rows = document.querySelectorAll('#dataTable tbody tr');
                        if (rows.length > 0) targetRow = rows[rows.length - 1];
                    }
                }
                if (targetRow) {
                    let rowData = {};
                    targetRow.querySelectorAll('.cell-data').forEach(input => rowData[input.name] = input.value);
                    let c1 = targetRow.querySelector('.sync-inst-court'); if (c1) rowData.sync_inst_court = c1.checked;
                    let c2 = targetRow.querySelector('.sync-court-next'); if (c2) rowData.sync_court_next = c2.checked;
                    rowData['cms_result'] = "";
                    rowData['title_result'] = "";
                    rowData['page_url'] = "";
                    addRow(rowData);
                    saveMemory(true); 
                    const newRows = document.querySelectorAll('#dataTable tbody tr');
                    if (isSingleView) {
                        currentSingleIndex = newRows.length - 1;
                        renderSingleView();
                    }
                    focusFirstVisibleField();
                }
            }
        });
        if (colCheckboxesContainer) {
            toggleableColumns.forEach(col => {
                const lbl = document.createElement('label');
                let isDefaultHidden = defaultHiddenCols.includes(col.id);
                lbl.innerHTML = `<input type="checkbox" class="col-toggle" value="${col.id}" ${isDefaultHidden ? '' : 'checked'}> ${col.name}`;
                colCheckboxesContainer.appendChild(lbl);
            });
        }
        const allColCheckboxes = document.querySelectorAll('.col-toggle');
        function applyColumnVisibility() {
            let hiddenCols = [];
            let cssRules = '';
            allColCheckboxes.forEach(cb => {
                if (!cb.checked) {
                    hiddenCols.push(cb.value);
                    cssRules += `body:not(.form-edit-cols) .${cb.value} { display: none !important; }\n`;
                    cssRules += `body.form-edit-cols .single-mode tbody tr.active-single td.${cb.value} { opacity: 0.3 !important; filter: grayscale(100%); background-color: #f9f9f9 !important; border: 2px dashed #999 !important; }\n`;
                }
            });
            dynamicStyle.innerHTML = cssRules;
            chrome.storage.local.set({ hiddenColumns: hiddenCols });
            document.querySelectorAll('.inline-eye').forEach(eye => {
                let isHidden = hiddenCols.includes(eye.dataset.col);
                eye.innerHTML = isHidden ? '🚫' : '👁️';
                eye.style.color = isHidden ? '#d32f2f' : '#4CAF50';
            });
        }
        allColCheckboxes.forEach(cb => cb.addEventListener('change', applyColumnVisibility));
        if (showAllColsBtn) {
            showAllColsBtn.addEventListener('click', () => {
                allColCheckboxes.forEach(cb => cb.checked = true);
                applyColumnVisibility();
            });
        }
        let suggestionTimeout;
        function updateNameSuggestions(dataArray) {
            clearTimeout(suggestionTimeout);
            suggestionTimeout = setTimeout(() => {
                chrome.storage.local.get(['savedNamesPl', 'savedNamesDef', 'savedOffences'], (result) => {
                    let plSet = new Set(result.savedNamesPl || []);
                    let defSet = new Set(result.savedNamesDef || []);
                    let offenceSet = new Set(result.savedOffences || []);
                    if (dataArray) {
                        dataArray.forEach(row => {
                            if (row.pl_eng && row.pl_eng.trim() !== '') plSet.add(row.pl_eng.trim());
                            if (row.def_eng && row.def_eng.trim() !== '') defSet.add(row.def_eng.trim());
                            if (row.offence && row.offence.trim() !== '') offenceSet.add(row.offence.trim());
                        });
                    }
                    let plArr = Array.from(plSet);
                    let defArr = Array.from(defSet);
                    let offenceArr = Array.from(offenceSet);
                    chrome.storage.local.set({ 'savedNamesPl': plArr, 'savedNamesDef': defArr, 'savedOffences': offenceArr });
                    refreshDatalistsDOM(); 
                });
            }, 500);
        }
        function addRow(data) {
            if (!tableBody) return;
            const tr = document.createElement('tr');
            let uid = Math.random().toString(36).substr(2, 9); 
            tr.setAttribute('data-uid', uid); 
            if(data.cms_result && data.cms_result !== "Error" && data.cms_result !== "Retry" && data.cms_result !== "Working...") tr.classList.add("success-row"); 
            let showRetry = (data.cms_result === "Error") ? "inline-block" : "none";
            let showOpen = (data.page_url && data.page_url !== "") ? "inline-block" : "none";
            let showRefresh = (data.page_url && data.page_url !== "") ? "inline-block" : "none";
            let tehsilVal = (data.tehsil && data.tehsil.trim() !== "") ? data.tehsil : (window.defaultTehsil || '');
            const now = new Date();
            const currDay = String(now.getDate()).padStart(2, '0');
            const currMonth = String(now.getMonth() + 1).padStart(2, '0');
            const currYear = now.getFullYear();
            const currentDateStr = `${currDay}-${currMonth}-${currYear}`;
            let instDateVal = data.inst_date !== undefined ? data.inst_date : currentDateStr;
            let courtDateVal = data.court_date !== undefined ? data.court_date : currentDateStr;
            let syncInstChecked = data.sync_inst_court !== undefined ? data.sync_inst_court : window.autoSyncDatesDefault;
            let syncCourtChecked = data.sync_court_next !== undefined ? data.sync_court_next : false;
            tr.innerHTML = `
                <td class="sr-no" data-label="Sr No." style="font-weight: bold; text-align: center; vertical-align: middle; background-color: #e9ecef;">
                    <span class="embossed-subcat" style="display:none;"></span>
                </td>
                <td class="col-tehsil" data-label="Tehsil"><input type="text" class="cell-data" name="tehsil" value="${tehsilVal}"></td>
                <td class="col-pl-eng" data-label="Plaintiff (Eng)"><input type="text" class="cell-data" name="pl_eng" list="pl-list" autocomplete="on" value="${data.pl_eng || ''}" placeholder="Type here..."></td>
                <td class="col-def-eng" data-label="Defendant (Eng) / VS"><input type="text" class="cell-data" name="def_eng" list="def-list" autocomplete="on" value="${data.def_eng || ''}" placeholder="Type here..."></td>
                <td class="col-inst-date" data-label="Inst. Date"><input type="text" class="cell-data" name="inst_date" value="${instDateVal}"></td>
                <td class="col-inst-no" data-label="Inst. No."><input type="text" class="cell-data" name="inst_no" value="${data.inst_no || ''}"></td>
                <td class="col-ahlmad-no" data-label="Ahlmad No."><input type="text" class="cell-data" name="ahlmad_no" value="${data.ahlmad_no || ''}"></td>
                <td class="col-court-date" data-label="Court Date">
                    <input type="text" class="cell-data" name="court_date" value="${courtDateVal}">
                    <div style="display:flex; align-items:center; font-size:11px; margin-top:4px; color:#555;">
                        <input type="checkbox" class="sync-inst-court" tabindex="-1" style="width:14px; height:14px; margin:0 4px 0 0; cursor:pointer;" ${syncInstChecked ? 'checked' : ''}> Same as Inst. Date
                    </div>
                </td>
                <td class="col-category" data-label="Category"><select class="cell-data category-select" name="category" data-preset-cat="${data.category || ''}"><option value="">Select Category</option></select></td>
                <td class="col-subcategory" data-label="Subcategory"><select class="cell-data subcategory-select" name="subcategory" data-preset-sub="${data.subcategory || ''}"><option value="">Select Subcategory</option></select></td>
                <td class="col-fortnightly" data-label="Fortnightly"><select class="cell-data" name="fortnightly"><option value="">Select Fortnightly</option><optgroup label="Criminal"><option value="1">Time Fixed Bail Applications Magistrage (3 Days) (Criminal)</option><option value="2">Time Fixed Bail Applications Sessions court (5 Days) (Criminal)</option><option value="3">Cancellation of Bail (15 Days) (Criminal)</option><option value="4">Imprisonment upto 7 Years (6 Months) (Criminal)</option><option value="5">Imprisonment above 7 Years Including Death Sentence (1 Year) (Criminal)</option><option value="6">Preventive Detention Cases (As early as possible) (Criminal)</option><option value="7">Transfer Applicatons u/s 526, 528, Cr.P.C (7 Days) (Criminal)</option><option value="8">Misc Application i.e Superdari, Disposal of Property etc (7 Days) (Criminal)</option><option value="9">Prioritized Narcotics Cases (Criminal)</option><option value="10">Criminal Revisions (Criminal)</option><option value="11">Anti Terrorism Cases (Criminal)</option><option value="12">Women Cases (Criminal)</option><option value="13">Juvenile Cases (Criminal)</option><option value="14">Cases of Overseas Pakistani (Either Complainant or Accused) (Criminal)</option><option value="15">Others - Criminal (Criminal)</option></optgroup><optgroup label="Civil"><option value="16">Time Fixed Stay Applications (15 Days) (Civil)</option><option value="17">Rent Cases (4 Months) (Civil)</option><option value="18">Appeals in rent Cases (2 Months) (Civil)</option><option value="19">Revision Petitions (3 Months) (Civil)</option><option value="20">Family Cases (3-6 Moths) (Civil)</option><option value="21">Appeals in Family Cases (30 Days) (Civil)</option><option value="22">Appeals Insolvency Cases (30 Days) (Civil)</option><option value="23">Review Application (30 Days) (Civil)</option><option value="24">Negotiable Instrument Cases u/s 37 CPC (90 Days) (Civil)</option><option value="25">Cases of the Overseas Pakistanis (6 Months) (Civil)</option><option value="26">Prioritized Women Cases (Civil)</option><option value="27">Juvenile Cases (Civil)</option><option value="28">Small Claims and Minor Offences (Civil)</option><option value="29">Trade, Commercial, Investment (Civil)</option><option value="30">Civil Execution Application (Civil)</option><option value="31">Civil Suit (Civil)</option><option value="32">Others - Civil (Civil)</option></optgroup></select></td>
                <td class="col-remarks" data-label="Remarks"><textarea class="cell-data" name="remarks">${data.remarks || ''}</textarea></td>
                <td class="col-moza" data-label="Mouza (Area)"><input type="text" class="cell-data" name="moza" value="${data.moza || ''}"></td>
                <td class="col-case-type" data-label="Case Type"><select class="cell-data" name="case_type"><option value="0">NA</option><option value="1">FIR</option><option value="2">Private Complaint</option></select></td>
                <td class="col-fir-no" data-label="FIR No."><input type="text" class="cell-data" name="fir_no" value="${data.fir_no || ''}"></td>
                <td class="col-fir-year" data-label="FIR Year"><input type="text" class="cell-data" name="fir_year" value="${data.fir_year || ''}"></td>
                <td class="col-offence" data-label="Offence"><input type="text" class="cell-data" name="offence" list="offence-list" autocomplete="on" value="${data.offence || ''}"></td>
                <td class="col-police-station" data-label="Police Station"><input type="text" list="police-list-${uid}" class="cell-data" name="police_station" value="${data.police_station || ''}" placeholder="Select Police"><datalist id="police-list-${uid}" class="police-datalist"></datalist></td>
                <td class="col-challan-status" data-label="Report u/s 173">
                    <select class="cell-data" name="challan_status">
                        <option value="NA" ${(!data.challan_status || data.challan_status === 'NA') ? 'selected' : ''}>NA</option>
                        <option value="Not Submitted" ${data.challan_status === 'Not Submitted' ? 'selected' : ''}>Not Submitted</option>
                        <option value="Supplementary" ${data.challan_status === 'Supplementary' ? 'selected' : ''}>Supplementary</option>
                        <option value="Incomplete" ${data.challan_status === 'Incomplete' ? 'selected' : ''}>Incomplete</option>
                        <option value="Complete" ${data.challan_status === 'Complete' ? 'selected' : ''}>Complete</option>
                    </select>
                </td>
                <td class="col-challan-date" data-label="Challan Date"><input type="text" class="cell-data" name="challan_date" value="${data.challan_date || ''}"></td>
                <td class="col-utp" data-label="UTP">
                    <select class="cell-data" name="is_utp">
                        <option value="No" ${(!data.is_utp || data.is_utp === 'No') ? 'selected' : ''}>No</option>
                        <option value="Yes" ${data.is_utp === 'Yes' ? 'selected' : ''}>Yes</option>
                    </select>
                </td>
                <td class="col-pfsa" data-label="PFSA">
                    <select class="cell-data" name="is_pfsa">
                        <option value="No" ${(!data.is_pfsa || data.is_pfsa === 'No') ? 'selected' : ''}>No</option>
                        <option value="Yes" ${data.is_pfsa === 'Yes' ? 'selected' : ''}>Yes</option>
                    </select>
                </td>
                <td class="col-civil-jurisdiction" data-label="Class">
                    <select class="cell-data" name="civil_jurisdiction">
                        <option value="" ${!data.civil_jurisdiction ? 'selected' : ''}>Select Civil Jurisdiction</option>
                        <option value="Class-I" ${data.civil_jurisdiction === 'Class-I' ? 'selected' : ''}>Class-I</option>
                        <option value="Class-II" ${data.civil_jurisdiction === 'Class-II' ? 'selected' : ''}>Class-II</option>
                        <option value="Class-III" ${data.civil_jurisdiction === 'Class-III' ? 'selected' : ''}>Class-III</option>
                    </select>
                </td>
                <td class="col-next-date" data-label="Next Date">
                    <input type="text" class="cell-data" name="next_date" value="${data.next_date || ''}">
                    <div style="display:flex; align-items:center; font-size:11px; margin-top:4px; color:#555;">
                        <input type="checkbox" class="sync-court-next" tabindex="-1" style="width:14px; height:14px; margin:0 4px 0 0; cursor:pointer;" ${syncCourtChecked ? 'checked' : ''}> Same as Court Date
                    </div>
                </td>
                <td class="col-stage" data-label="Case Stage"><input type="text" list="stage-list-${uid}" class="cell-data" name="stage" value="${data.stage || ''}" placeholder="Select Stage"><datalist id="stage-list-${uid}" class="stage-datalist"></datalist></td>
                <td class="col-custom-heading" data-label="Custom Heading"><input type="text" list="heading-list-${uid}" class="cell-data" name="custom_heading" value="${data.custom_heading || ''}" placeholder="Select Heading"><datalist id="heading-list-${uid}" class="heading-datalist"></datalist></td>
                <td class="col-short-order" data-label="Short Order"><textarea class="cell-data" name="short_order">${data.short_order || ''}</textarea></td>
                <td class="col-cms-result" data-label="CMS Number / Error">
                    <input type="text" class="cell-data readonly-cell" name="cms_result" value="${data.cms_result || ''}" readonly>
                    <input type="hidden" class="cell-data" name="page_url" value="${data.page_url || ''}">
                </td>
                <td class="col-title-result" data-label="Case Title / Details">
                    <textarea class="cell-data readonly-cell" name="title_result" readonly>${data.title_result || ''}</textarea>
                    <div class="edit-title-box" style="display: none; flex-direction: column; margin-top: 8px; border-top: 1px dashed #d81b60; padding-top: 8px; width: 100%; box-sizing: border-box;">
                        <input type="text" class="edit-plaintiff-urdu" placeholder="سائل" style="width: 100%; font-family: 'Jameel Noori Nastaleeq', Arial; font-size: 16px; padding: 6px; box-sizing: border-box; text-align: right; direction: rtl; border: 1px solid #ccc; border-radius: 3px;">
                        <div style="text-align: center; font-weight: bold; font-family: 'Jameel Noori Nastaleeq', Arial; font-size: 16px; margin: 4px 0;">بنام</div>
                        <input type="text" class="edit-defendant-urdu" placeholder="مسئول علیہ" style="width: 100%; font-family: 'Jameel Noori Nastaleeq', Arial; font-size: 16px; padding: 6px; box-sizing: border-box; text-align: right; direction: rtl; border: 1px solid #ccc; border-radius: 3px;">
                        <div style="display: flex; gap: 5px; margin-top: 10px; width: 100%;">
                            <button class="update-title-btn" style="flex: 1; background-color: #d81b60; color: white; border: none; padding: 8px; border-radius: 3px; cursor: pointer; font-weight: bold; font-size: 12px; margin: 0;">Update</button>
                            <button class="cancel-title-btn" style="flex: 1; background-color: #9e9e9e; color: white; border: none; padding: 8px; border-radius: 3px; cursor: pointer; font-weight: bold; font-size: 12px; margin: 0;">Cancel</button>
                        </div>
                    </div>
                </td>
                <td class="col-action" data-label="Action" style="white-space: normal; min-width: 150px; text-align: left;">
                    <button class="process-single-row" style="background-color:#008CBA;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px;margin-right:4px; margin-bottom:4px;" title="Upload this single entry">Process Single</button>
                    <button class="edit-title-row" style="background-color:#ff5722;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px;margin-right:4px; margin-bottom:4px; display:${showOpen};" title="Edit Urdu Title">Edit Title</button>
                    <button class="print-title-row" style="background-color:#673AB7;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px;margin-right:4px; margin-bottom:4px; display:${showOpen};" title="Print Case Title">Print Title</button>
                    <button class="print-qr-row" style="background-color:#E91E63;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px;margin-right:4px; margin-bottom:4px; display:${showOpen};" title="Print QR Code">Print QR</button>
                    <button class="open-row" style="background-color:#4CAF50;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px;margin-right:4px; margin-bottom:4px; display:${showOpen};" title="Open Case URL">Open</button>
                    <button class="refresh-row" style="background-color:#009688;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px;margin-right:4px; margin-bottom:4px; display:${showRefresh};" title="Refresh Case Details">Refresh</button>
                    <button class="retry-row" style="background-color:#9C27B0;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px;margin-right:4px; margin-bottom:4px; display:${showRetry};" title="Retry this single case">Retry</button>
                    <button class="dup-row" style="background-color:#2196F3;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px;margin-right:4px; margin-bottom:4px;">Copy</button>
                    <button class="delete-row" style="background-color:#ff9800;color:white;border:none;cursor:pointer;padding:8px 12px;border-radius:4px; margin-bottom:4px;">Del</button>
                </td>
            `;
            tableBody.appendChild(tr);
            updateSerialNumbers(); 
            toggleableColumns.forEach(col => {
                let td = tr.querySelector(`td.${col.id}`);
                if (td) {
                    let eye = document.createElement('span');
                    eye.className = 'inline-eye';
                    eye.dataset.col = col.id;
                    eye.innerHTML = '👁️'; 
                    eye.title = "Toggle Field Visibility";
                    eye.addEventListener('click', (e) => {
                        e.stopPropagation(); 
                        let cb = document.querySelector(`.col-toggle[value="${col.id}"]`);
                        if (cb) {
                            cb.checked = !cb.checked; 
                            applyColumnVisibility(); 
                        }
                    });
                    td.appendChild(eye);
                }
            });
            const categoryEl = tr.querySelector('.category-select');
            const subcategorySelect = tr.querySelector('.subcategory-select');
            if (categoryEl && subcategorySelect) {
                categoryEl.addEventListener('change', () => { 
                    let cleanText = categoryEl.value.trim();
                    chrome.storage.local.get(['scrapedSubcats'], (res) => {
                        let options = (res.scrapedSubcats || {})[cleanText] || [];
                        let html = '<option value="">Select Subcategory</option>'; 
                        options.forEach(o => html += `<option value="${o}">${o}</option>`);
                        subcategorySelect.innerHTML = html; 
                        let presetSub = subcategorySelect.getAttribute('data-preset-sub');
                        if (presetSub && Array.from(subcategorySelect.options).some(o => o.value === presetSub)) {
                            subcategorySelect.value = presetSub;
                            subcategorySelect.removeAttribute('data-preset-sub');
                            subcategorySelect.dispatchEvent(new Event('change'));
                        }
                        saveMemory(false);
                    });
                });
            }
            if (subcategorySelect) {
                subcategorySelect.addEventListener('change', () => {
                    let emb = tr.querySelector('.embossed-subcat');
                    let text = subcategorySelect.options[subcategorySelect.selectedIndex]?.text || "";
                    if (emb) {
                        if (subcategorySelect.value && subcategorySelect.value !== "") {
                            emb.innerText = text;
                            emb.style.display = 'inline-block';
                        } else {
                            emb.style.display = 'none';
                        }
                    }
                    saveMemory(false);
                });
                if (data.subcategory) {
                    setTimeout(() => {
                        let emb = tr.querySelector('.embossed-subcat');
                        let text = subcategorySelect.options[subcategorySelect.selectedIndex]?.text || data.subcategory;
                        if (emb && data.subcategory !== "") {
                            emb.innerText = text;
                            emb.style.display = 'inline-block';
                        }
                    }, 200);
                }
            }
            if (data.fortnightly) {
                let fnSelect = tr.querySelector('select[name="fortnightly"]');
                if (fnSelect) fnSelect.value = data.fortnightly;
            }
            if (data.case_type !== undefined) {
                let ctSelect = tr.querySelector('select[name="case_type"]');
                if (ctSelect) {
                    if (data.case_type === '0' || data.case_type === 'NA' || data.case_type === '') ctSelect.value = '0';
                    else if (data.case_type === '1' || data.case_type === 'FIR') ctSelect.value = '1';
                    else if (data.case_type === '2' || data.case_type === 'Private Complaint') ctSelect.value = '2';
                    else ctSelect.value = '0'; 
                }
            }
            let caseTypeSelect = tr.querySelector('select[name="case_type"]');
            const toggleNAFields = () => {
                if (!caseTypeSelect) return;
                let isNA = caseTypeSelect.value === '0';
                if (isNA) {
                    tr.classList.add('is-na');
                } else {
                    tr.classList.remove('is-na');
                }
                let fieldsToHide = ['fir_no', 'fir_year', 'offence', 'police_station', 'challan_status', 'challan_date', 'is_utp', 'is_pfsa'];
                let valuesCleared = false;
                fieldsToHide.forEach(f => {
                    let inputEl = tr.querySelector(`[name="${f}"]`);
                    if (inputEl) {
                        inputEl.style.visibility = isNA ? 'hidden' : 'visible'; 
                        let tdEl = inputEl.closest('td');
                        if (tdEl) {
                            if (isNA) tdEl.classList.add('hide-na');
                            else tdEl.classList.remove('hide-na');
                        }
                        if (isNA) {
                            let defaultVal = '';
                            if (f === 'challan_status') defaultVal = 'NA';
                            else if (f === 'is_utp' || f === 'is_pfsa') defaultVal = 'No';
                            if (inputEl.value !== defaultVal) {
                                inputEl.value = defaultVal;
                                valuesCleared = true;
                            }
                        }
                    }
                });
                let classInput = tr.querySelector('[name="civil_jurisdiction"]');
                if (classInput) {
                    let classTd = classInput.closest('td');
                    if (classTd) {
                        if (!isNA) {
                            classTd.classList.add('hide-class-auto'); 
                        } else {
                            classTd.classList.remove('hide-class-auto'); 
                        }
                    }
                }
                if (valuesCleared) {
                    saveMemory(false);
                }
            };
            if (caseTypeSelect) {
                caseTypeSelect.addEventListener('change', toggleNAFields);
                toggleNAFields(); 
            }
            populateGeneralLists(tr); 
            tr.querySelectorAll('.cell-data').forEach(i => { 
                i.addEventListener('input', () => saveMemory(false)); 
                i.addEventListener('change', () => saveMemory(false)); 
            });
            const plInput = tr.querySelector('input[name="pl_eng"]');
            const defInput = tr.querySelector('input[name="def_eng"]');
            [plInput, defInput].forEach(input => {
                if(input) {
                    input.addEventListener('input', function() {
                        let isAutoCorON = autoCorToggle ? autoCorToggle.checked : true;
                        if(isAutoCorON && window.autoCorrectDict) {
                            let text = this.value;
                            let cursorP = this.selectionStart;
                            let isChanged = false;
                            let words = text.split(' ');
                            let newWords = words.map(w => {
                                let lower = w.toLowerCase();
                                if(window.autoCorrectDict[lower]) {
                                    isChanged = true;
                                    return window.autoCorrectDict[lower];
                                }
                                return w;
                            });
                            if(isChanged) {
                                let newText = newWords.join(' ');
                                let diff = newText.length - text.length;
                                this.value = newText;
                                this.setSelectionRange(cursorP + diff, cursorP + diff);
                                saveMemory(false);
                            }
                        }
                    });
                    input.addEventListener('blur', function() {
                        let text = this.value;
                        let isChanged = false;
                        let isAutoCapON = autoCapToggle ? autoCapToggle.checked : true; 
                        if(isAutoCapON) {
                            const lowercaseExceptions = ['etc', 'alias', 'urf', 'vs', 'v'];
                            const uppercaseAcronyms = ['sho', 'sdpo', 'asp', 'sp', 'dpo', 'dsp', 'si', 'asi'];
                            let words = text.split(' ');
                            let newWords = words.map(w => {
                                if (!w) return w;
                                let lowerW = w.toLowerCase();
                                let resultWord = w;
                                if (lowercaseExceptions.includes(lowerW)) {
                                    resultWord = lowerW;
                                } else if (uppercaseAcronyms.includes(lowerW)) {
                                    resultWord = lowerW.toUpperCase();
                                } else if (w === w.toUpperCase() && w.match(/[a-zA-Z]/)) {
                                    resultWord = w;
                                } else {
                                    resultWord = w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
                                }
                                if (resultWord !== w) isChanged = true;
                                return resultWord;
                            });
                            text = newWords.join(' ');
                        }
                        if(isChanged) {
                            this.value = text;
                            saveMemory(false); 
                        }
                    });
                }
            });
            const dateFields = ['inst_date', 'court_date', 'challan_date', 'next_date'];
            dateFields.forEach(fieldName => {
                let inputEl = tr.querySelector(`input[name="${fieldName}"]`);
                if (inputEl) {
                    inputEl.addEventListener('blur', function() {
                        if (!this.value) return;
                        let val = this.value.trim();
                        const now = new Date();
                        const currDay = String(now.getDate()).padStart(2, '0');
                        const currMonth = String(now.getMonth() + 1).padStart(2, '0');
                        const currYear = now.getFullYear();
                        const currentDateStr = `${currDay}-${currMonth}-${currYear}`;
                        let d = null, m = null, y = currYear;
                        let isValid = false;
                        if (/^\d{1,2}$/.test(val)) {
                            d = val; 
                            m = currMonth;
                        } else if (/^(\d{1,2})[-/.](\d{1,2})$/.test(val)) {
                            let match = val.match(/^(\d{1,2})[-/.](\d{1,2})$/);
                            d = match[1]; 
                            m = match[2];
                        } else if (/^\d{3}$/.test(val)) {
                            d = val.substring(0, 2); 
                            m = val.substring(2, 3);
                        } else if (/^\d{4}$/.test(val)) {
                            d = val.substring(0, 2); 
                            m = val.substring(2, 4);
                        } else if (/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/.test(val)) {
                            let match = val.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/);
                            d = match[1]; 
                            m = match[2]; 
                            y = match[3].length === 2 ? "20" + match[3] : match[3];
                        }
                        if (d !== null && m !== null) {
                            let dayNum = parseInt(d, 10);
                            let monthNum = parseInt(m, 10);
                            if (dayNum >= 1 && dayNum <= 31 && monthNum >= 1 && monthNum <= 12) {
                                this.value = `${String(dayNum).padStart(2, '0')}-${String(monthNum).padStart(2, '0')}-${y}`;
                                isValid = true;
                            }
                        }
                        if (!isValid) {
                            this.value = currentDateStr;
                        }
                        if (fieldName === 'inst_date') {
                            let cChk = tr.querySelector('.sync-inst-court');
                            if (cChk && cChk.checked) {
                                let cInput = tr.querySelector('input[name="court_date"]');
                                if (cInput) {
                                    cInput.value = this.value;
                                    let nChk = tr.querySelector('.sync-court-next');
                                    let nInput = tr.querySelector('input[name="next_date"]');
                                    if (nChk && nChk.checked && nInput) nInput.value = this.value;
                                }
                            }
                        }
                        else if (fieldName === 'court_date') {
                            let nChk = tr.querySelector('.sync-court-next');
                            if (nChk && nChk.checked) {
                                let nInput = tr.querySelector('input[name="next_date"]');
                                if (nInput) nInput.value = this.value;
                            }
                        }
                        saveMemory(false);
                    });
                    inputEl.addEventListener('input', function() {
                        if (fieldName === 'inst_date') {
                            let cChk = tr.querySelector('.sync-inst-court');
                            if (cChk && cChk.checked) {
                                let cInput = tr.querySelector('input[name="court_date"]');
                                if (cInput) {
                                    cInput.value = this.value;
                                    let nChk = tr.querySelector('.sync-court-next');
                                    let nInput = tr.querySelector('input[name="next_date"]');
                                    if (nChk && nChk.checked && nInput) nInput.value = this.value;
                                }
                            }
                        }
                        else if (fieldName === 'court_date') {
                            let nChk = tr.querySelector('.sync-court-next');
                            if (nChk && nChk.checked) {
                                let nInput = tr.querySelector('input[name="next_date"]');
                                if (nInput) nInput.value = this.value;
                            }
                        }
                    });
                }
            });
            let chkInstCourt = tr.querySelector('.sync-inst-court');
            if (chkInstCourt) {
                chkInstCourt.addEventListener('change', function() {
                    if (this.checked) {
                        let instInput = tr.querySelector('input[name="inst_date"]');
                        let courtInput = tr.querySelector('input[name="court_date"]');
                        if (instInput && courtInput) {
                            courtInput.value = instInput.value;
                            let chkCourtNext = tr.querySelector('.sync-court-next');
                            let nextInput = tr.querySelector('input[name="next_date"]');
                            if (chkCourtNext && chkCourtNext.checked && nextInput) {
                                nextInput.value = instInput.value;
                            }
                            saveMemory(false);
                        }
                    } else {
                        saveMemory(false);
                    }
                });
            }
            let chkCourtNext = tr.querySelector('.sync-court-next');
            if (chkCourtNext) {
                chkCourtNext.addEventListener('change', function() {
                    if (this.checked) {
                        let courtInput = tr.querySelector('input[name="court_date"]');
                        let nextInput = tr.querySelector('input[name="next_date"]');
                        if (courtInput && nextInput) {
                            nextInput.value = courtInput.value;
                            saveMemory(false);
                        }
                    } else {
                        saveMemory(false);
                    }
                });
            }
            tr.querySelector('.process-single-row').addEventListener('click', () => { 
                let resInput = tr.querySelector('input[name="cms_result"]');
                let currentVal = resInput ? resInput.value.trim() : "";
                if (currentVal !== "" && currentVal !== "Error" && currentVal !== "Retry" && currentVal !== "Working...") {
                    if (!confirm("Yeh case already process ho chuka hai. Kya aap isko dobara process karna chahte hain?")) {
                        return;
                    }
                }
                if (resInput) resInput.value = "Working...";
                let titleInput = tr.querySelector('[name="title_result"]');
                if (titleInput) titleInput.value = "";
                tr.style.backgroundColor = ""; 
                tr.classList.remove("success-row"); 
                tr.querySelector('.retry-row').style.display = 'none'; 
                tr.querySelector('.open-row').style.display = 'none'; 
                let refBtn = tr.querySelector('.refresh-row');
                if (refBtn) refBtn.style.display = 'none';
                let ptBtn = tr.querySelector('.print-title-row');
                let pqBtn = tr.querySelector('.print-qr-row');
                let editBtn = tr.querySelector('.edit-title-row');
                if(ptBtn) ptBtn.style.display = 'none';
                if(pqBtn) pqBtn.style.display = 'none';
                if(editBtn) editBtn.style.display = 'none';
                let rowData = {}; 
                tr.querySelectorAll('.cell-data').forEach(input => rowData[input.name] = input.value); 
                let processId = Date.now() + Math.floor(Math.random() * 1000);
                tr.setAttribute('data-process-id', processId);
                prepareSplitScreen(() => {
                    chrome.runtime.sendMessage({ action: "process_single_row", data: rowData, rowIndex: processId });
                });
                saveMemory(false);
            });
            tr.querySelector('.edit-title-row').addEventListener('click', () => {
                let editBox = tr.querySelector('.edit-title-box');
                let titleArea = tr.querySelector('[name="title_result"]');
                let plInput = tr.querySelector('.edit-plaintiff-urdu');
                let defInput = tr.querySelector('.edit-defendant-urdu');
                if (editBox.style.display === 'none') {
                    editBox.style.display = 'flex'; 
                    let lines = titleArea.value.split('\n');
                    let firstLine = lines[0] || ""; 
                    let parts = firstLine.split('بنام');
                    if(parts.length >= 2) {
                        plInput.value = parts[0].trim();
                        defInput.value = parts[1].trim();
                    } else {
                        plInput.value = firstLine.trim();
                        defInput.value = "";
                    }
                } else {
                    editBox.style.display = 'none';
                }
            });
            tr.querySelector('.cancel-title-btn').addEventListener('click', () => {
                let editBox = tr.querySelector('.edit-title-box');
                if (editBox) {
                    editBox.style.display = 'none';
                }
            });
            tr.querySelector('.update-title-btn').addEventListener('click', () => {
                let urlInput = tr.querySelector('input[name="page_url"]');
                if (!urlInput || !urlInput.value) return;
                let originalUrl = urlInput.value;
                let editUrl = originalUrl + "/edit#step-1";
                let plValue = tr.querySelector('.edit-plaintiff-urdu').value.trim();
                let defValue = tr.querySelector('.edit-defendant-urdu').value.trim();
                let btn = tr.querySelector('.update-title-btn');
                btn.innerText = "Updating... Please wait";
                btn.disabled = true;
                chrome.tabs.create({ url: editUrl, active: false }, (tab) => {
                    let targetTabId = tab.id;
                    let checkInterval = setInterval(() => {
                        chrome.tabs.get(targetTabId, (updatedTab) => {
                            if (chrome.runtime.lastError || !updatedTab) {
                                clearInterval(checkInterval);
                                btn.innerText = "Update"; btn.disabled = false;
                                return;
                            }
                            if (updatedTab.status === 'complete') {
                                clearInterval(checkInterval);
                                setTimeout(() => {
                                    chrome.scripting.executeScript({
                                        target: { tabId: targetTabId },
                                        func: (pl, def) => {
                                            let plEl = document.getElementById('ce_party1_urdu');
                                            let defEl = document.getElementById('ce_party2_urdu');
                                            if(plEl) {
                                                plEl.value = pl;
                                                plEl.dispatchEvent(new Event('input', {bubbles:true}));
                                                plEl.dispatchEvent(new Event('change', {bubbles:true}));
                                            }
                                            if(defEl) {
                                                defEl.value = def;
                                                defEl.dispatchEvent(new Event('input', {bubbles:true}));
                                                defEl.dispatchEvent(new Event('change', {bubbles:true}));
                                            }
                                            let saveBtn = document.querySelector('button[type="submit"]') || document.querySelector('.btn-success') || document.querySelector('.btn-primary');
                                            if(saveBtn) {
                                                saveBtn.click();
                                            } else {
                                                let form = plEl ? plEl.closest('form') : document.querySelector('form');
                                                if(form) form.submit();
                                            }
                                            return true;
                                        },
                                        args: [plValue, defValue]
                                    }, (res) => {
                                        setTimeout(() => {
                                            chrome.tabs.remove(targetTabId);
                                            btn.innerText = "Updated Successfully ✓";
                                            let titleArea = tr.querySelector('[name="title_result"]');
                                            let lines = titleArea.value.split('\n');
                                            let newFirstLine = plValue;
                                            if(defValue) newFirstLine += " بنام " + defValue;
                                            lines[0] = newFirstLine;
                                            titleArea.value = lines.join('\n');
                                            saveMemory(false);
                                            setTimeout(() => { 
                                                btn.innerText = "Update"; 
                                                btn.disabled = false; 
                                                tr.querySelector('.edit-title-box').style.display = 'none'; 
                                            }, 2000);
                                        }, 2500); 
                                    });
                                }, 1500); 
                            }
                        });
                    }, 500);
                });
            });
            tr.querySelector('.print-title-row').addEventListener('click', () => {
                let url = tr.querySelector('input[name="page_url"]').value;
                let catInput = tr.querySelector('.category-select').value;
                if(url && url !== "") {
                    let idMatch = url.match(/\/(\d+)$/);
                    if(idMatch) {
                        let caseId = idMatch[1];
                        let cleanCat = catInput ? catInput.trim() : "";
                        let type = CRIMINAL_CATEGORIES.includes(cleanCat) ? "2" : "1";
                        let printUrl = `https://dsj.punjab.gov.pk/admin/caseentries/casetitlepage/${caseId}/${type}`;
                        window.open(printUrl, '_blank');
                    }
                }
            });
            tr.querySelector('.print-qr-row').addEventListener('click', () => {
                let url = tr.querySelector('input[name="page_url"]').value;
                let cms = tr.querySelector('input[name="cms_result"]').value;
                if(url && url !== "" && cms && cms !== "Error" && cms !== "Working..." && cms !== "Saved") {
                    let idMatch = url.match(/\/(\d+)$/);
                    if(idMatch) {
                        let caseId = idMatch[1];
                        let qrUrl = `https://dsj.punjab.gov.pk/admin/caseentries/qrtitlepage/${caseId}/${cms}?size=100`;
                        document.getElementById('qrImage').src = qrUrl;
                        document.getElementById('qrCmsText').innerText = cms;
                        let savedLeft = localStorage.getItem('qrPosLeft') || '1in';
                        let savedTop = localStorage.getItem('qrPosTop') || '1.5in';
                        let qrBoxDiv = document.getElementById('draggableQrBox');
                        if (qrBoxDiv) {
                            qrBoxDiv.style.left = savedLeft;
                            qrBoxDiv.style.top = savedTop;
                        }
                        let overlay = document.getElementById('qrPrintOverlay');
                        if (overlay) overlay.style.display = 'block';
                    }
                } else {
                    alert("Valid URL ya CMS Number majood nahi hai.");
                }
            });
            tr.querySelector('.open-row').addEventListener('click', () => {
                let url = tr.querySelector('input[name="page_url"]').value;
                if(url && url !== "") {
                    window.open(url, '_blank');
                }
            });
            tr.querySelector('.refresh-row').addEventListener('click', () => {
                let urlInput = tr.querySelector('input[name="page_url"]');
                let titleArea = tr.querySelector('[name="title_result"]');
                if (!urlInput || !urlInput.value || !titleArea) return;
                let url = urlInput.value;
                let originalText = titleArea.value;
                titleArea.value = "Fetching updated details...";
                chrome.tabs.create({ url: url, active: false }, (tab) => {
                    let targetTabId = tab.id;
                    let checkInterval = setInterval(() => {
                        chrome.tabs.get(targetTabId, (updatedTab) => {
                            if (chrome.runtime.lastError || !updatedTab) {
                                clearInterval(checkInterval);
                                titleArea.value = originalText;
                                return;
                            }
                            if (updatedTab.status === 'complete') {
                                clearInterval(checkInterval);
                                setTimeout(() => {
                                    const extractCode = `
                                        (function() {
                                            let extractedTitle = "";
                                            let urduSpan = document.querySelector('.urdu-font-22');
                                            if (urduSpan && urduSpan.innerText && urduSpan.innerText.trim() !== "") {
                                                extractedTitle = urduSpan.innerText.trim();
                                            } else if (urduSpan && urduSpan.textContent && urduSpan.textContent.trim() !== "") {
                                                extractedTitle = urduSpan.textContent.trim();
                                            }
                                            let firYear = "";
                                            let policeStation = "";
                                            let subcategoryEng = "";
                                            let caseInfoBlocks = document.querySelectorAll('.case-info');
                                            caseInfoBlocks.forEach(block => {
                                                let cTitle = block.querySelector('.case-title');
                                                let cDetail = block.querySelector('.case-detail');
                                                if (cTitle && cDetail) {
                                                    let titleText = (cTitle.innerText || cTitle.textContent || "").trim().toLowerCase();
                                                    let detailText = (cDetail.innerText || cDetail.textContent || "").trim();
                                                    if (titleText.includes("fir/year") && detailText !== "N/A" && detailText !== "") firYear = detailText;
                                                    else if (titleText.includes("police station") && detailText !== "N/A" && detailText !== "") policeStation = detailText;
                                                    else if (titleText.includes("case subcategory") && detailText !== "N/A" && detailText !== "") subcategoryEng = detailText;
                                                }
                                            });
                                            return {
                                                title: extractedTitle,
                                                firYear: firYear,
                                                policeStation: policeStation,
                                                subcategoryEng: subcategoryEng
                                            };
                                        })();
                                    `;
                                    function processResults(results) {
                                        chrome.tabs.remove(targetTabId);
                                        let data = null;
                                        if (results && results[0]) {
                                            data = results[0].result || results[0];
                                        }
                                        if (!data || !data.title) {
                                            titleArea.value = originalText;
                                            return;
                                        }
                                        chrome.storage.local.get(['subcatUrduMap', 'policeUrduMap'], (storageRes) => {
                                            let urduMap = storageRes.subcatUrduMap || {};
                                            let policeMap = storageRes.policeUrduMap || {};
                                            let finalTitle = data.title;
                                            if (data.subcategoryEng) {
                                                let urduSubcat = urduMap[data.subcategoryEng.toLowerCase()];
                                                if (urduSubcat) finalTitle += "\n" + urduSubcat;
                                            }
                                            let extraDetails = [];
                                            if (data.firYear) extraDetails.push(data.firYear);
                                            if (data.policeStation) {
                                                let urduPolice = policeMap[data.policeStation.toLowerCase()] || data.policeStation;
                                                extraDetails.push(urduPolice);
                                            }
                                            if (extraDetails.length > 0) {
                                                finalTitle += "\n" + extraDetails.join(", ");
                                            }
                                            titleArea.value = finalTitle;
                                            saveMemory(false);
                                        });
                                    }
                                    if (chrome.scripting && chrome.scripting.executeScript) {
                                        chrome.scripting.executeScript({
                                            target: { tabId: targetTabId },
                                            func: () => {
                                                let extractedTitle = "";
                                                let urduSpan = document.querySelector('.urdu-font-22');
                                                if (urduSpan && urduSpan.innerText && urduSpan.innerText.trim() !== "") {
                                                    extractedTitle = urduSpan.innerText.trim();
                                                } else if (urduSpan && urduSpan.textContent && urduSpan.textContent.trim() !== "") {
                                                    extractedTitle = urduSpan.textContent.trim();
                                                }
                                                let firYear = "";
                                                let policeStation = "";
                                                let subcategoryEng = "";
                                                let caseInfoBlocks = document.querySelectorAll('.case-info');
                                                caseInfoBlocks.forEach(block => {
                                                    let cTitle = block.querySelector('.case-title');
                                                    let cDetail = block.querySelector('.case-detail');
                                                    if (cTitle && cDetail) {
                                                        let titleText = (cTitle.innerText || cTitle.textContent || "").trim().toLowerCase();
                                                        let detailText = (cDetail.innerText || cDetail.textContent || "").trim();
                                                        if (titleText.includes("fir/year") && detailText !== "N/A" && detailText !== "") firYear = detailText;
                                                        else if (titleText.includes("police station") && detailText !== "N/A" && detailText !== "") policeStation = detailText;
                                                        else if (titleText.includes("case subcategory") && detailText !== "N/A" && detailText !== "") subcategoryEng = detailText;
                                                    }
                                                });
                                                return {
                                                    title: extractedTitle,
                                                    firYear: firYear,
                                                    policeStation: policeStation,
                                                    subcategoryEng: subcategoryEng
                                                };
                                            }
                                        }, processResults);
                                    } else if (chrome.tabs && chrome.tabs.executeScript) {
                                        chrome.tabs.executeScript(targetTabId, { code: extractCode }, processResults);
                                    } else {
                                        chrome.tabs.remove(targetTabId);
                                        titleArea.value = originalText;
                                    }
                                }, 500); 
                            }
                        });
                    }, 500);
                });
            });
            tr.querySelector('.retry-row').addEventListener('click', () => { 
                let resInput = tr.querySelector('input[name="cms_result"]');
                let titleInput = tr.querySelector('[name="title_result"]');
                if (resInput) resInput.value = "Working...";
                if (titleInput) titleInput.value = "";
                tr.style.backgroundColor = ""; 
                tr.classList.remove("success-row"); 
                tr.querySelector('.retry-row').style.display = 'none'; 
                tr.querySelector('.open-row').style.display = 'none'; 
                let refBtn = tr.querySelector('.refresh-row');
                if (refBtn) refBtn.style.display = 'none';
                let ptBtn = tr.querySelector('.print-title-row');
                let pqBtn = tr.querySelector('.print-qr-row');
                let editBtn = tr.querySelector('.edit-title-row');
                if(ptBtn) ptBtn.style.display = 'none';
                if(pqBtn) pqBtn.style.display = 'none';
                if(editBtn) editBtn.style.display = 'none';
                let rowData = {}; 
                tr.querySelectorAll('.cell-data').forEach(input => rowData[input.name] = input.value); 
                let processId = Date.now() + Math.floor(Math.random() * 1000);
                tr.setAttribute('data-process-id', processId);
                prepareSplitScreen(() => {
                    chrome.runtime.sendMessage({ action: "process_single_row", data: rowData, rowIndex: processId });
                });
                saveMemory(false);
            });
            tr.querySelector('.dup-row').addEventListener('click', () => { 
                let rowData = {}; 
                tr.querySelectorAll('.cell-data').forEach(input => rowData[input.name] = input.value); 
                let c1 = tr.querySelector('.sync-inst-court'); if (c1) rowData.sync_inst_court = c1.checked;
                let c2 = tr.querySelector('.sync-court-next'); if (c2) rowData.sync_court_next = c2.checked;
                rowData['cms_result'] = ""; rowData['title_result'] = ""; rowData['page_url'] = ""; 
                addRow(rowData); 
                saveMemory(false); 
            });
            tr.querySelector('.delete-row').addEventListener('click', () => { 
                tr.remove(); 
                updateSerialNumbers(); 
                saveMemory(false); 
            });
        }
        function populateGeneralLists(rowElement = document) {
            chrome.storage.local.get(['scrapedSubcats', 'scrapedStages', 'scrapedPolice', 'scrapedHeadings'], (res) => {
                let stagesHtml = (res.scrapedStages || []).map(o => `<option value="${o}">`).join('');
                let policeHtml = (res.scrapedPolice || []).map(o => `<option value="${o}">`).join('');
                let headingsHtml = (res.scrapedHeadings || []).map(o => `<option value="${o}">`).join('');
                rowElement.querySelectorAll('.stage-datalist').forEach(el => el.innerHTML = stagesHtml);
                rowElement.querySelectorAll('.police-datalist').forEach(el => el.innerHTML = policeHtml);
                rowElement.querySelectorAll('.heading-datalist').forEach(el => el.innerHTML = headingsHtml);
                let catHtml = '<option value="">Select Category</option>';
                if (res.scrapedSubcats) {
                    let cats = Object.keys(res.scrapedSubcats).sort();
                    cats.forEach(c => catHtml += `<option value="${c}">${c}</option>`);
                }
                rowElement.querySelectorAll('.category-select').forEach(catEl => {
                    let presetCat = catEl.getAttribute('data-preset-cat') || catEl.value;
                    catEl.innerHTML = catHtml;
                    if (presetCat) { catEl.value = presetCat; }
                    let row = catEl.closest('tr');
                    let subCatEl = row.querySelector('.subcategory-select');
                    let presetSub = subCatEl.getAttribute('data-preset-sub') || subCatEl.value;
                    let subOptions = (res.scrapedSubcats || {})[catEl.value] || [];
                    let subHtml = '<option value="">Select Subcategory</option>';
                    subOptions.forEach(o => subHtml += `<option value="${o}">${o}</option>`);
                    subCatEl.innerHTML = subHtml;
                    if (presetSub) { 
                        subCatEl.setAttribute('data-preset-sub', presetSub); 
                        if (Array.from(subCatEl.options).some(o => o.value === presetSub)) {
                            subCatEl.value = presetSub;
                        }
                    }
                });
            });
        }
        async function fetchWebsiteData(url, dataType = 'list') { 
            try {
                let res = await fetch(url); let html = await res.text();
                let parser = new DOMParser(); let doc = parser.parseFromString(html, 'text/html');
                let rows = doc.querySelectorAll('table tbody tr');
                if (dataType === 'subcat') {
                    let dict = {};
                    let urduMap = {}; 
                    rows.forEach(row => {
                        let cols = row.querySelectorAll('td');
                        if (cols.length >= 4) { 
                            let cat = cols[1].innerText.trim();
                            let sub = cols[2].innerText.trim();
                            let urduName = cols[3].innerText.trim(); 
                            if (cat && sub) { 
                                if (!dict[cat]) dict[cat] = []; 
                                if (!dict[cat].includes(sub)) dict[cat].push(sub); 
                                if (urduName) {
                                    urduMap[sub.toLowerCase()] = urduName; 
                                }
                            }
                        }
                    });
                    return { subcats: dict, urduMap: urduMap };
                } else if (dataType === 'police') {
                    let list = [];
                    let urduMap = {}; 
                    rows.forEach(row => {
                        let cols = row.querySelectorAll('td');
                        if (cols.length >= 3) { 
                            let name = cols[1].innerText.trim();
                            let urduName = cols[2].innerText.trim(); 
                            if (name) { 
                                if (!list.includes(name)) list.push(name); 
                                if (urduName) {
                                    urduMap[name.toLowerCase()] = urduName; 
                                }
                            }
                        }
                    });
                    return { list: list, urduMap: urduMap };
                } else {
                    let list = [];
                    rows.forEach(row => {
                        let cols = row.querySelectorAll('td');
                        if (cols.length >= 2) { let name = cols[1].innerText.trim(); if (name && !list.includes(name)) list.push(name); }
                    });
                    return list;
                }
            } catch (e) { 
                if (dataType === 'subcat') return { subcats: {}, urduMap: {} }; 
                if (dataType === 'police') return { list: [], urduMap: {} }; 
                return []; 
            }
        }
        async function fetchDashboardData() { 
            try {
                let res = await fetch('https://dsj.punjab.gov.pk/admin/dashboard'); 
                let html = await res.text();
                let parser = new DOMParser(); 
                let doc = parser.parseFromString(html, 'text/html');
                let tehsil = "";
                let judgeName = "CMS Batch Case Instituter"; 
                let judgeTitleEl = doc.querySelector('h3.judge-title');
                if (judgeTitleEl) {
                    let clone = judgeTitleEl.cloneNode(true);
                    let span = clone.querySelector('span');
                    if (span) {
                        span.remove(); 
                    }
                    judgeName = clone.textContent.replace(/&nbsp;/g, ' ').trim() || "CMS Batch Case Instituter";
                    let origSpan = judgeTitleEl.querySelector('span');
                    if (origSpan) {
                        let text = origSpan.innerText.trim();
                        let parts = text.split(',');
                        if (parts.length >= 3) {
                            tehsil = parts[parts.length - 2].trim();
                        } else if (parts.length === 2) {
                            tehsil = parts[1].trim();
                        }
                    }
                } else {
                    let spans = doc.querySelectorAll('span');
                    for (let span of spans) {
                        let text = span.innerText.trim();
                        if ((text.toLowerCase().includes('judge') || text.toLowerCase().includes('magistrate')) && text.includes(',')) {
                            let parts = text.split(',');
                            if (parts.length >= 3) {
                                tehsil = parts[parts.length - 2].trim();
                                break;
                            } else if (parts.length === 2) {
                                tehsil = parts[1].trim();
                                break;
                            }
                        }
                    }
                }
                return { tehsil: tehsil, judgeName: judgeName };
            } catch (e) { 
                return { tehsil: "", judgeName: "CMS Batch Case Instituter" }; 
            }
        }
        if(syncDataBtn) {
            syncDataBtn.addEventListener('click', () => { 
                saveMemory(false); 
                syncDataBtn.innerText = "Connecting..."; 
                syncDataBtn.disabled = true;
                let extTabId;
                chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                    extTabId = tabs[0].id;
                    let isSyncing = false; 
                    chrome.tabs.create({ url: 'https://dsj.punjab.gov.pk/admin/dashboard', active: true }, (tab) => {
                        let targetTabId = tab.id;
                        let checkInterval = setInterval(() => {
                            chrome.tabs.get(targetTabId, (updatedTab) => {
                                if (chrome.runtime.lastError || !updatedTab) {
                                    clearInterval(checkInterval);
                                    if(!isSyncing) {
                                        syncDataBtn.innerText = "Sync Form Data";
                                        syncDataBtn.disabled = false;
                                    }
                                    return;
                                }
                                if (updatedTab.status === 'complete' && updatedTab.url) {
                                    if (updatedTab.url.includes('/admin/dashboard') && !isSyncing) {
                                        isSyncing = true; 
                                        clearInterval(checkInterval);
                                        syncDataBtn.innerText = "Syncing Data...";
                                        Promise.all([
                                            fetchWebsiteData('https://dsj.punjab.gov.pk/admin/usercasesubcategories', 'subcat'), 
                                            fetchWebsiteData('https://dsj.punjab.gov.pk/admin/userstages', 'list'),           
                                            fetchWebsiteData('https://dsj.punjab.gov.pk/admin/userpolicestations', 'police'),   
                                            fetchWebsiteData('https://dsj.punjab.gov.pk/admin/userdefineheadings', 'list'),
                                            fetchDashboardData() 
                                        ]).then(results => {
                                            let dashData = results[4];
                                            chrome.storage.local.set({ 
                                                'scrapedSubcats': results[0].subcats, 
                                                'subcatUrduMap': results[0].urduMap,
                                                'scrapedStages': results[1], 
                                                'scrapedPolice': results[2].list, 
                                                'policeUrduMap': results[2].urduMap,
                                                'scrapedHeadings': results[3],
                                                'defaultTehsil': dashData.tehsil,
                                                'judgeName': dashData.judgeName 
                                            }, () => {
                                                try {
                                                    chrome.tabs.remove(targetTabId, () => {
                                                        let err = chrome.runtime.lastError; 
                                                        chrome.tabs.update(extTabId, {active: true});
                                                        syncDataBtn.innerText = "Sync Form Data"; 
                                                        syncDataBtn.disabled = false;
                                                        alert("Sync Form Data successfully!"); 
                                                        location.reload(); 
                                                    });
                                                } catch(e) {
                                                    location.reload();
                                                }
                                            });
                                        }).catch(err => {
                                            chrome.tabs.update(extTabId, {active: true});
                                            syncDataBtn.innerText = "Sync Form Data"; 
                                            syncDataBtn.disabled = false;
                                            alert("Syncing failed."); 
                                        });
                                    }
                                }
                            });
                        }, 1500);
                    });
                });
            });
        }
        function saveMemory(updateSuggestions = false) {
            let tableData = [];
            document.querySelectorAll('#dataTable tbody tr').forEach(row => {
                let rowData = {}; 
                row.querySelectorAll('.cell-data').forEach(input => rowData[input.name] = input.value); 
                let c1 = row.querySelector('.sync-inst-court');
                if (c1) rowData.sync_inst_court = c1.checked;
                let c2 = row.querySelector('.sync-court-next');
                if (c2) rowData.sync_court_next = c2.checked;
                tableData.push(rowData);
            });
            chrome.storage.local.set({ 'cmsData': tableData });
            if (updateSuggestions) {
                updateNameSuggestions(tableData);
            }
        }
        function loadMemory() {
            chrome.storage.local.get(['cmsData', 'hiddenColumns', 'defaultTehsil', 'autoCap', 'autoCor', 'autoCorDict', 'qfConfigs', 'autoSyncDates', 'judgeName'], (result) => {
                if (result.defaultTehsil) {
                    window.defaultTehsil = result.defaultTehsil;
                }
                if (result.judgeName && result.judgeName.trim() !== "") {
                    let titleLink = document.querySelector('.header-title a');
                    if (titleLink) {
                        titleLink.innerText = result.judgeName;
                    }
                }
                if (autoCapToggle) autoCapToggle.checked = result.autoCap !== false; 
                if (autoCorToggle) autoCorToggle.checked = result.autoCor !== false; 
                if (result.autoSyncDates !== undefined) {
                    window.autoSyncDatesDefault = result.autoSyncDates;
                    if (autoSyncDatesToggle) autoSyncDatesToggle.checked = result.autoSyncDates;
                }
                window.autoCorrectDict = result.autoCorDict || DEFAULT_DICT;
                window.qfConfigs = result.qfConfigs || {};
                if (result.cmsData && result.cmsData.length > 0) {
                    result.cmsData.forEach(addRow); 
                } else { 
                    addRow({}); 
                }
                let hidden = result.hiddenColumns;
                if (!hidden || hidden.length === 0) {
                    hidden = defaultHiddenCols;
                }
                allColCheckboxes.forEach(cb => { 
                    cb.checked = !hidden.includes(cb.value); 
                });
                applyColumnVisibility();
                if (dataTable) dataTable.classList.add('single-mode');
                renderSingleView();
                refreshDatalistsDOM();
            });
        }
        if(clearBtn) {
            clearBtn.addEventListener('click', () => {
                if (confirm("Are you sure you want to clear all data? (Aapki Typing Suggestions delete nahi hongi)")) {
                    chrome.storage.local.remove(['cmsData', 'hiddenColumns', 'lockedFields'], () => {
                        if (tableBody) tableBody.innerHTML = ''; 
                        addRow({}); 
                        alert("Memory Cleared!"); 
                        location.reload();
                    });
                }
            });
        }
        if(processBtn) {
            processBtn.addEventListener('click', () => {
                if (isProcessing) return;
                let rowDataList = [];
                let duplicateFound = false;
                let dupMsg = "";
                const allTableRows = document.querySelectorAll('#dataTable tbody tr');
                for (let i = 0; i < allTableRows.length; i++) {
                    let resInput = allTableRows[i].querySelector('input[name="cms_result"]');
                    let currentRes = resInput ? resInput.value.trim() : "";
                    if (currentRes === "" || currentRes === "Retry") {
                        let rowData = {};
                        let isEmpty = true;
                        allTableRows[i].querySelectorAll('.cell-data').forEach(input => {
                            if (input.name !== 'cms_result' && input.name !== 'title_result' && input.name !== 'page_url') {
                                rowData[input.name] = input.value.trim();
                                if(input.value.trim() !== "") isEmpty = false;
                            }
                        });
                        if (!isEmpty) {
                            let dataString = JSON.stringify(rowData);
                            for(let j = 0; j < rowDataList.length; j++) {
                                if(rowDataList[j].data === dataString) {
                                    duplicateFound = true;
                                    dupMsg = `SR NO. ${rowDataList[j].sr} and ${i + 1} are same do you want to proceed?`;
                                    break;
                                }
                            }
                            if(duplicateFound) break;
                            rowDataList.push({data: dataString, sr: i + 1});
                        }
                    }
                }
                if (duplicateFound) {
                    if (!confirm(dupMsg)) {
                        return; 
                    }
                }
                if (isSingleView) {
                    isSingleView = false;
                    if (formEditColsMode) {
                        formEditColsMode = false;
                        document.body.classList.remove('form-edit-cols');
                        let formEditBar = document.getElementById('formEditBar');
                        if (formEditBar) formEditBar.style.display = 'none';
                    }
                    renderSingleView();
                }
                const columnsToKeep = ['col-next-date', 'col-custom-heading'];
                allColCheckboxes.forEach(cb => {
                    cb.checked = columnsToKeep.includes(cb.value);
                });
                applyColumnVisibility();
                let pendingRows = 0;
                const rows = document.querySelectorAll('#dataTable tbody tr');
                rows.forEach(r => {
                    let res = r.querySelector('input[name="cms_result"]');
                    let currentVal = res ? res.value.trim() : "";
                    if (currentVal === "" || currentVal === "Retry") {
                        pendingRows++;
                    }
                });
                if (pendingRows > 0) {
                    queueStats.total = pendingRows;
                    queueStats.processed = 0;
                    queueStats.success = 0;
                    queueStats.failed = 0;
                    updateQueueUI();
                } else {
                    alert("Koi aisi row nahi mili jo process hone wali ho.");
                    return;
                }
                isProcessing = true; 
                processBtn.innerText = "Processing..."; 
                processBtn.style.backgroundColor = "#ff9800"; 
                prepareSplitScreen(() => {
                    processNextRow(); 
                });
            });
        }
        function processNextRow() {
            const rows = document.querySelectorAll('#dataTable tbody tr');
            let rowIndexToProcess = -1; let rowDataToProcess = null; let rowProcessId = null;
            for (let i = 0; i < rows.length; i++) {
                let cmsResultInput = rows[i].querySelector('input[name="cms_result"]');
                let currentVal = cmsResultInput ? cmsResultInput.value.trim() : "";
                if (currentVal === "" || currentVal === "Retry") {
                    rowIndexToProcess = i; 
                    rowDataToProcess = {};
                    rows[i].querySelectorAll('.cell-data').forEach(input => rowDataToProcess[input.name] = input.value);
                    rowProcessId = Date.now() + Math.floor(Math.random() * 1000);
                    rows[i].setAttribute('data-process-id', rowProcessId);
                    break; 
                }
            }
            if (rowIndexToProcess === -1) {
                isProcessing = false; 
                if (processBtn) {
                    processBtn.innerText = "Start Processing"; 
                    processBtn.style.backgroundColor = "#008CBA";
                }
                alert("All rows processed successfully!"); return;
            }
            if (isSingleView) {
                currentSingleIndex = rowIndexToProcess;
                renderSingleView();
            }
            const targetRow = rows[rowIndexToProcess];
            if(targetRow) {
                let rInput = targetRow.querySelector('input[name="cms_result"]');
                if (rInput) rInput.value = "Working...";
            }
            prepareSplitScreen(() => {
                chrome.runtime.sendMessage({ action: "process_single_row", data: rowDataToProcess, rowIndex: rowProcessId });
            });
        }
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === "row_form_filled") {
                if (dashboardWindowId !== null) {
                    chrome.windows.update(dashboardWindowId, { focused: true });
                }
                const targetRow = document.querySelector(`tr[data-process-id="${request.rowIndex}"]`);
                if (targetRow) {
                    let cInput = targetRow.querySelector('input[name="cms_result"]');
                    let tInput = targetRow.querySelector('[name="title_result"]');
                    if (cInput) cInput.value = request.result.cmsNo || "Error"; 
                    if (tInput) tInput.value = request.result.title || "Done";
                    queueStats.processed++;
                    if (request.result.cmsNo === "Error") {
                        targetRow.style.backgroundColor = "#ffebee"; 
                        let rBtn = targetRow.querySelector('.retry-row');
                        let oBtn = targetRow.querySelector('.open-row');
                        let refBtn = targetRow.querySelector('.refresh-row');
                        let ptBtn = targetRow.querySelector('.print-title-row');
                        let pqBtn = targetRow.querySelector('.print-qr-row');
                        let editBtn = targetRow.querySelector('.edit-title-row');
                        if(rBtn) rBtn.style.display = 'inline-block'; 
                        if(oBtn) oBtn.style.display = 'none'; 
                        if(refBtn) refBtn.style.display = 'none'; 
                        if(ptBtn) ptBtn.style.display = 'none';
                        if(pqBtn) pqBtn.style.display = 'none';
                        if(editBtn) editBtn.style.display = 'none';
                        queueStats.failed++;
                    } else {
                        targetRow.style.backgroundColor = ""; 
                        targetRow.classList.add("success-row"); 
                        let rBtn = targetRow.querySelector('.retry-row');
                        if (rBtn) rBtn.style.display = 'none'; 
                        let urlInput = targetRow.querySelector('input[name="page_url"]');
                        if (urlInput && request.result.url) {
                            urlInput.value = request.result.url;
                            let oBtn = targetRow.querySelector('.open-row');
                            let refBtn = targetRow.querySelector('.refresh-row');
                            let ptBtn = targetRow.querySelector('.print-title-row');
                            let pqBtn = targetRow.querySelector('.print-qr-row');
                            let editBtn = targetRow.querySelector('.edit-title-row');
                            if(oBtn) oBtn.style.display = 'inline-block';
                            if(refBtn) refBtn.style.display = 'inline-block';
                            if(ptBtn) ptBtn.style.display = 'inline-block';
                            if(pqBtn) pqBtn.style.display = 'inline-block';
                            if(editBtn) editBtn.style.display = 'inline-block';
                        }
                        queueStats.success++;
                    }
                    updateQueueUI();
                    saveMemory(false); 
                    setTimeout(() => {
                        if (!isProcessing) return; 
                        processNextRow(); 
                    }, 1000); 
                }
            }
        });
        loadMemory();
    });
});